<div class="container-fluid">
    <?php $this->load->view('user/pages/head_info') ;?>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-sm-4" style="margin-bottom: 15px;">
                            <div class="card" id="support_issues_border">
                                <div class="card-body">
                                    <h5>
                                        <i class="fa fa-google-wallet"></i>
                                        &nbsp;
                                        My Wallet Amount
                                    </h5>
                                    <br>

                                    <div id="user_wallet_div"></div>

                                    <hr>

                                    <br>

                                    <h6>
                                        <i class="fa fa-check-circle"></i>
                                        &nbsp;
                                        Top Up Your Wallet Via :
                                    </h6>

                                    <ul class="nav nav-tabs customtab" role="tablist">
                                        <li class="nav-item"> <a class="nav-link active" data-toggle="tab" href="#mpesa" role="tab"><span class="hidden-sm-up"><i class="ti-info"></i></span> <span class="hidden-xs-down">Mpesa</span></a> </li>
                                        <li class="nav-item"> <a class="nav-link" data-toggle="tab" href="#pesapal" role="tab"><span class="hidden-sm-up"><i class="ti-pencil"></i></span> <span class="hidden-xs-down">Pesapal</span></a> </li>
                                    </ul>
                                    <div class="tab-content">
                                        <div class="tab-pane active" id="mpesa" role="tabpanel">
                                            <br>
                                            <h6>
                                                Direct Mpesa Top Up
                                            </h6>
                                            <hr>
                                            <form action="<?php echo base_url('payment/top_up_wallet')?>" method="post" id="top_up_wallet_form">
                                                <div class="form-group">
                                                    <input type="number" class="form-control" name="amount" placeholder="Enter Amount" required>
                                                    <input type="hidden" name="phone" value="<?php echo $details->phone?>">
                                                    <input type="hidden" name="acc_no" value="<?php echo $details->doc_no?>">
                                                    <input type="hidden" name="user_id" value="<?php echo $s_id ;?>">
                                                </div>
                                                <div class="form-group">
                                                    <button class="btn btn-success" style="width: 100%;" type="submit">
                                                        <i class="glyphicon glyphicon-check"></i>
                                                        &nbsp;
                                                        Top Up Wallet
                                                    </button>
                                                </div>
                                            </form>
                                        </div>
                                        <div class="tab-pane" id="pesapal" role="tabpanel">
                                            <br>
                                            <h6>
                                                Pesapal Top Up
                                            </h6>
                                            <hr>
                                            <form action="<?php echo base_url('payment/process_payment')?>" method="post">
                                                <div class="form-group">
                                                    <input type="hidden" name="fname" value="<?php echo $details->fname ;?>">
                                                </div>
                                                <div class="form-group">
                                                    <input type="hidden" name="lname" value="<?php echo $details->other_names ;?>">
                                                </div>
                                                <div class="form-group">
                                                    <input type="hidden" name="email" value="<?php echo $details->email ;?>">
                                                </div>
                                                <div class="form-group">
                                                    <input type="hidden" name="phone" value="<?php echo $details->phone ;?>">
                                                </div>
                                                <div class="form-group">
                                                    <input type="number" id="amount" name="amount" class="form-control" min="1" max="999" placeholder="Enter Amount" required>
                                                </div>
                                                <div class="form-group">
                                                    <div class="text-center">
                                                        <button type="submit" class="btn btn-success" style="width: 100%;">
                                                            <i class="glyphicon glyphicon-check"></i>
                                                            &nbsp;
                                                            Process Payment
                                                        </button>
                                                    </div>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-8">
                            <div class="card" id="support_issues_border">
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-sm-9">
                                            <ul class="nav nav-tabs customtab" role="tablist">
                                                <li class="nav-item"> <a class="nav-link active" data-toggle="tab" href="#usage" role="tab"><span class="hidden-sm-up"><i class="ti-info"></i></span> <span class="hidden-xs-down">Wallet Transactions</span></a> </li>
                                                <li class="nav-item"> <a class="nav-link" data-toggle="tab" href="#topups" role="tab"><span class="hidden-sm-up"><i class="ti-pencil"></i></span> <span class="hidden-xs-down">Top Up History</span></a> </li>

                                            </ul>
                                        </div>
                                        <div class="col-sm-3">
                                            <a class="btn btn-inverse btn-sm" href="" style="width: 100%;">
                                                <i class="fa fa-refresh"></i>
                                                &nbsp;
                                                Refresh Records
                                            </a>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-12">
                                            <div class="tab-content">
                                                <div class="tab-pane active" id="usage" role="tabpanel">
                                                    <br>
                                                    <h4>
                                                        My Wallet Usage
                                                    </h4>
                                                    <hr>
                                                    <div class="table-responsive">
                                                        <table id="myTable2" class="table table-bordered table-striped">
                                                            <thead>
                                                            <tr>
                                                                <th> Type</th>
                                                                <th> Amount</th>
                                                                <th> Date</th>
                                                            </tr>
                                                            </thead>
                                                            <tbody>
                                                            <?php foreach ($trans as $tran) {?>

                                                                <tr>
                                                                    <td>
                                                                        <?php echo $tran->type?>
                                                                    </td>
                                                                    <td>
                                                                        <?php echo "Kshs. ".number_format($tran->amount) ;?>
                                                                    </td>
                                                                    <td>
                                                                        <?php echo date_format(date_create($tran->date), 'jS F Y') ;?>
                                                                    </td>
                                                                </tr>
                                                            <?php }?>
                                                            </tbody>
                                                            <tfoot>
                                                            <tr>
                                                                <th> Type</th>
                                                                <th> Amount</th>
                                                                <th> Date</th>
                                                            </tr>
                                                            </tfoot>
                                                        </table>
                                                    </div>
                                                </div>
                                                <div class="tab-pane" id="topups" role="tabpanel">
                                                    <br>
                                                    <h4>
                                                        My Top Up History
                                                    </h4>
                                                    <hr>
                                                    <div class="table-responsive">
                                                        <table id="myTable" class="table table-bordered table-striped">
                                                            <thead>
                                                            <tr>
                                                                <th> Amount</th>
                                                                <th>Transaction Type</th>
                                                                <th> Transaction Code</th>
                                                                <th>Transaction Date</th>
                                                            </tr>
                                                            </thead>
                                                            <tbody>
                                                            <?php foreach ($top_ups as $top_up) {?>

                                                                <tr>
                                                                    <td>
                                                                        <?php echo "Kshs. ".number_format($top_up->amount) ;?>
                                                                    </td>
                                                                    <td>
                                                                        <?php echo $top_up->trans_type?>
                                                                    </td>
                                                                    <td>
                                                                        <?php echo $top_up->trans_id ;?>
                                                                    </td>
                                                                    <td>
                                                                        <?php echo date_format(date_create($top_up->date), 'jS F Y') ;?>
                                                                    </td>
                                                                </tr>
                                                            <?php }?>
                                                            </tbody>
                                                            <tfoot>
                                                            <tr>
                                                                <th> Amount</th>
                                                                <th>Transaction Type</th>
                                                                <th> TransactionCode</th>
                                                                <th>Transaction Date</th>
                                                            </tr>
                                                            </tfoot>
                                                        </table>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php $this->load->view('user/pages/social_links') ;?>
    </div>
</div>

<script src="<?php echo base_url() ?>assets/node_modules/jquery/jquery.min.js"></script>

<script type="text/javascript">
    (function fetch_user_wallet_amount() {
        $.ajax({
            type: "POST",
            url: "<?php echo base_url('member/user_wallet_amount/'.$s_id)?>",
            success: function (res) {
                $("#user_wallet_div").html(res);
            },
            complete: function () {
                setTimeout(fetch_user_wallet_amount, 1000);
            }
        });
    })();
</script>
