<div class="container-fluid">
    <?php $this->load->view('user/pages/head_info') ;?>
    <div class="row">
        <div class="col-lg-3 col-md-3">
            <div class="card">
                <a href="<?php echo base_url('member/print_card')?>">
                    <div class="card-body">
                        <div class="d-flex p-10 no-block">
                            <div class="align-slef-center">
                                <h5 class="text-muted m-b-0" style="margin-top: 10px;">
                                    Print Member's Card
                                </h5>
                            </div>
                            <div class="align-self-center display-6 ml-auto"><i class="text-success icon-Printer"></i>
                            </div>
                        </div>
                    </div>
                    <div class="progress">
                        <div class="progress-bar bg-success" role="progressbar" aria-valuenow="100" aria-valuemin="0"
                             aria-valuemax="100" style="width:100%; height:3px;"><span
                                    class="sr-only"></span></div>
                    </div>
                </a>
            </div>
        </div>
        <div class="col-lg-3 col-md-3">
            <div class="card">
                <a href="<?php echo base_url('member/upgrade')?>">
                    <div class="card-body">
                        <div class="d-flex p-10 no-block">
                            <div class="align-slef-center" style="margin-top: 10px;">
                                <h5 class="text-muted m-b-0">
                                    Upgrade Membership
                                </h5>
                            </div>
                            <div class="align-self-center display-6 ml-auto"><i
                                        class="text-primary icon-Upgrade"></i></div>
                        </div>
                    </div>
                    <div class="progress">
                        <div class="progress-bar bg-primary" role="progressbar" aria-valuenow="100" aria-valuemin="0"
                             aria-valuemax="100" style="width:100%; height:3px;"><span
                                    class="sr-only"></span></div>
                    </div>
                </a>
            </div>
        </div>
        <div class="col-lg-3 col-md-3">
            <div class="card">
                <a href="<?php echo base_url('member/upgrade')?>">
                    <div class="card-body">
                        <div class="d-flex p-10 no-block">
                            <div class="align-slef-center">
                                <h5 class="text-muted m-b-0">
                                    Renew Membership
                                </h5>
                            </div>
                            <div class="align-self-center display-6 ml-auto"><i class="text-danger icon-Contrast"></i>
                            </div>
                        </div>
                    </div>
                    <div class="progress">
                        <div class="progress-bar bg-success" role="progressbar" aria-valuenow="100" aria-valuemin="0"
                             aria-valuemax="100" style="width:100%; height:3px;"><span
                                    class="sr-only"></span></div>
                    </div>
                </a>
            </div>
        </div>
        <div class="col-lg-3 col-md-3">
            <div class="card">
                <a href="<?php echo base_url('member/donate')?>">
                    <div class="card-body">
                        <div class="d-flex p-10 no-block">
                            <div class="align-slef-center" style="margin-top: 10px;">
                                <h5 class="text-muted m-b-0">
                                    Donate
                                </h5>
                            </div>
                            <div class="align-self-center display-6 ml-auto"><i class="text-danger icon-Money"></i>
                            </div>
                        </div>
                    </div>
                    <div class="progress">
                        <div class="progress-bar bg-primary" role="progressbar" aria-valuenow="100" aria-valuemin="0"
                             aria-valuemax="100" style="width:100%; height:3px;"><span
                                    class="sr-only"></span></div>
                    </div>
                </a>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-sm-6">
            <div class="card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-12">
                            <h5>
                                ODM Recent Tweets
                            </h5>
                            <hr>
                            <div class="col-md-12">
                                <div style="max-height: 45vh; overflow: auto;">
                                    <a class="twitter-timeline" href="https://twitter.com/TheODMparty?ref_src=twsrc%5Etfw">Tweets by TheODMparty</a> <script async src="https://platform.twitter.com/widgets.js" charset="utf-8"></script>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-sm-6">
            <div class="card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-12">
                            <h5>
                                My Recent Activities
                            </h5>
                            <hr>
                            <div class="col-md-12">
                                <div style="max-height: 45vh; overflow: auto;">
                                    <div class="table-responsive m-t-10">
                                        <table id="myTable" class="table table-bordered table-striped">
                                            <thead>
                                            <tr>
                                                <th> Activity</th>
                                                <th> Date</th>
                                            </tr>
                                            </thead>
                                            <tbody>
                                            <?php foreach ($activities as $activity) {?>
                                                <tr>
                                                    <td>
                                                        <?php echo $activity->message ;?>
                                                    </td>
                                                    <td>
                                                        <?php echo date_format(date_create($activity->date), 'jS F, Y'). " at ". date_format(date_create($activity->date), 'H:i:s')?>
                                                    </td>
                                                </tr>
                                            <?php }?>
                                            </tbody>
                                            <tfoot>
                                            <tr>
                                                <th> Activity</th>
                                                <th> Date</th>
                                            </tr>
                                            </tfoot>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php $this->load->view('user/pages/social_links')?>
    </div>
</div>

<script src="<?php echo base_url() ?>assets/node_modules/jquery/jquery.min.js"></script>

<script type="text/javascript">
    (function check_membership_status() {
        $.ajax({
            type: "POST",
            url: "<?php echo base_url('member/check_member_expiry_date/'.$s_id)?>",
            success: function () {
            },
            complete: function () {
                setTimeout(check_membership_status, 3600);
            }
        });
    })();
</script>

