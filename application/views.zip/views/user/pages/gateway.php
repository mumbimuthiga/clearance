<div class="container-fluid">
    <?php $this->load->view('user/pages/head_info') ;?>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="card" id="support_issues_border">
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-sm-12">
                                            <h5>
                                                Choose your desired payment method to complete transaction
                                            </h5>
                                            <hr>
                                            <?php
                                            echo
                                                '
                                                    <iframe src="'.$iframe_src.'" width="100%" height="550px"  scrolling="no" frameBorder="0">
                                                        <p>Browser unable to load iFrame</p>
                                                    </iframe>
                                                    ';
                                            ?>
                                        </div>
                                    </div>
                                    <hr>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php $this->load->view('user/pages/social_links') ;?>
    </div>
</div>
