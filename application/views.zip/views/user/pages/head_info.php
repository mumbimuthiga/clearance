<div class="row page-titles">
    <div class="col-md-4 align-self-center">
        <h6 class="text-themecolor">
           <b>
               <b>
                   Member >
               </b>
           </b>
            &nbsp;
            <?php echo ucwords(strtolower(str_replace('_', ' ', $page)), "")?>
        </h6>
    </div>
    <div class="col-md-4">
        <div class="row">
            <div class="col-7">
                <h6>
                    <b>
                        Membership Status :
                    </b>
                </h6>
            </div>
            <div class="col-5">
                <b>
                    <?php
                    echo $this->User_model->get_member_status($s_id);
                    ?>
                </b>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="row">
            <div class="col-7">
                <h6>
                    <b>
                        Current Member Type :
                    </b>
                </h6>
            </div>
            <div class="col-5">
                <p class="text-warning">
                    <b>
                       <span class="label label-primary">
                            <?php

                            $member_type = $this->User_model->get_membership($details->member_type ? $details->member_type : '0');

                            echo $member_type->name;
                            ?>
                       </span>
                    </b>
                </p>
            </div>
        </div>
    </div>
</div>