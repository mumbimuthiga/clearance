<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Members Card</title>

    <style type="text/css">
        html {
            background: #FAF7F2;
            background-image: url('https://s3.postimg.org/s1n3ji1ur/paper_fibers_2_X.png');
            box-sizing: border-box;
            font-family: 'Lato', sans-serif;
            font-size: 14px;
            font-weight: 400;
        }

        *, *:before, *:after {
            box-sizing: inherit;
        }

        .u-clearfix:before,
        .u-clearfix:after {
            content: " ";
            display: table;
        }

        .u-clearfix:after {
            clear: both;
        }

        .u-clearfix {
            *zoom: 1;
        }

        .subtle {
            color: #aaa;
        }

        .card-container {
            margin: 25px auto 0;
            position: relative;
            width: 692px;
        }

        .card-new {
            background-color: #fff;
            padding: 30px;
            position: relative;
            box-shadow: 0 0 5px rgba(75, 75, 75, .07);
            z-index: 1;
        }

        .card-body-new {
            display: inline-block;
            float: left;
            width: 310px;
        }

        .card-number {
            margin-top: 15px;
        }

        .card-circle {
            border: 1px solid #aaa;
            border-radius: 50%;
            display: inline-block;
            line-height: 22px;
            font-size: 12px;
            height: 25px;
            text-align: center;
            width: 25px;
        }

        .card-author {
            display: block;
            font-size: 12px;
            letter-spacing: .5px;
            margin: 15px 0 0;
            text-transform: uppercase;
        }

        .card-title {
            font-family: 'Cormorant Garamond', serif;
            font-size: 60px;
            font-weight: 300;
            line-height: 60px;
            margin: 10px 0;
        }

        .card-description {
            display: inline-block;
            font-weight: 300;
            line-height: 22px;
            margin: 10px 0;
        }

        .card-read {
            cursor: pointer;
            font-size: 14px;
            font-weight: 700;
            letter-spacing: 6px;
            margin: 5px 0 20px;
            position: relative;
            text-align: right;
            text-transform: uppercase;
        }

        .card-read:after {
            background-color: #b8bddd;
            content: "";
            display: block;
            height: 1px;
            position: absolute;
            top: 9px;
            width: 75%;
        }

        .card-tag {
            float: right;
            margin: 5px 0 0;
        }

        .card-media {
            float: right;
        }

        .card-shadow {
            background-color: #fff;
            box-shadow: 0 2px 25px 2px rgba(0, 0, 0, 1), 0 2px 50px 2px rgba(0, 0, 0, 1), 0 0 100px 3px rgba(0, 0, 0, .25);
            height: 1px;
            margin: -1px auto 0;
            width: 80%;
            z-index: -1;
        }
    </style>
</head>
<body>
<div class="card-container" id="member_cards">
    <div class="card-new u-clearfix">
        <div class="card-body-new">
            <span class="card-number card-circle subtle">
                01
            </span>
            <span class="card-author subtle">John Smith</span>
            <h2 class="card-title">New Brunch Recipe</h2>
            <span class="card-description subtle">These last few weeks I have been working hard on a new brunch recipe for you all.</span>
            <div class="card-read">Read</div>
            <span class="card-tag card-circle subtle">C</span>
        </div>
        <img src="<?php echo base_url(); ?>assets/images/logo2.png" alt="" class="card-media" />
    </div>
    <div class="card-shadow"></div>
</div>
<hr>
<button class="btn btn-success" id="print_card">
    Print Card
</button>
</body>
</html>