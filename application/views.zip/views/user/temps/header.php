<header class="topbar">
    <?php
    $details = $this->db->get_where('members', array('user_id' => $s_id))->row();
    $paid_reg_fee = $this->db->get_where('reg_fee', array('user_id' => $s_id))->num_rows();

    ?>
    <nav class="navbar top-navbar navbar-expand-md navbar-light">
        <div class="navbar-header">
            <a class="navbar-brand" href="<? echo base_url() ?>member/dashboard" style="margin-top: ;">
                <b>
                    <img src="<?php echo base_url(); ?>assets/images/logo3.png" alt="ODM Logo"
                         class="img-responsive dark-logo"/>
                </b>
            </a>
        </div>

        <div class="navbar-collapse">
            <ul class="navbar-nav mr-auto">
                <!-- This is  -->
                <li class="nav-item"><a class="nav-link nav-toggler hidden-md-up waves-effect waves-dark"
                                        href="javascript:void(0)"><i class="sl-icon-menu"></i></a></li>
                <li class="nav-item"><a class="nav-link sidebartoggler hidden-sm-down waves-effect waves-dark"
                                        href="javascript:void(0)"><i class="sl-icon-menu"></i></a></li>
            </ul>
            <ul class="navbar-nav my-lg-0">
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle waves-effect waves-dark" href="#" data-toggle="dropdown"
                       aria-haspopup="true" aria-expanded="false"> <i class="icon-Bell"></i>
                        <?php if($paid_reg_fee == 0) {?>
                            <div class="notify"><span class="heartbit"></span> <span class="point"></span></div>
                        <?php }?>
                    </a>
                    <div class="dropdown-menu dropdown-menu-right mailbox animated bounceInDown" style="height: 170px !important;">
                        <ul>
                            <li>
                                <div class="drop-title">Notification (s)</div>
                            </li>
                            <li>
                                <div class="message-center" style="padding: 20px  !important;">
                                    <?php if($paid_reg_fee == 0) {?>
                                        <div class="row" style="padding-bottom: 20px;">
                                            <div class="col-12">
                                                <h6>
                                                    You have not paid your registration fees.
                                                </h6>
                                                <button class="btn btn-inverse btn-sm" id="pay_reg_fee">
                                                    Pay Fee
                                                </button>
                                            </div>
                                        </div>
                                    <?php }?>
                                </div>
                            </li>
                        </ul>
                    </div>
                </li>

                <li class="nav-item dropdown u-pro">

                    <a class="nav-link dropdown-toggle waves-effect waves-dark profile-pic" data-toggle="dropdown"
                       aria-haspopup="true" aria-expanded="false">

                        <img src="<?php echo base_url() ?>assets/images/profile.png" alt="user" class=""/>
                        <span class="hidden-md-down">
                           <?php echo $details->fname . " " . $details->other_names; ?> &nbsp;<i class="fa fa-angle-down"></i>
                        </span>
                    </a>

                    <div class="dropdown-menu dropdown-menu-right">
                        <ul class="dropdown-user">
                            <li>
                                <div class="dw-user-box">
                                    <div class="u-text">
                                        <h4> <?php echo $details->email; ?></h4>
                                    </div>
                                </div>
                            </li>
                            <li role="separator" class="divider"></li>
                            <li>
                                <a href="<?php echo base_url() ?>member/wallet">
                                    <i class="fa fa-google-wallet"></i>
                                    &nbsp;
                                    My Wallet
                                </a>
                            </li>
                            <li role="separator" class="divider"></li>
                            <li>
                                <a href="<?php echo base_url() ?>member/profile">
                                    <i class="fa fa-user"></i>
                                    &nbsp;
                                    My Profile
                                </a>
                            </li>
                            <li role="separator" class="divider"></li>
                            <li><a href="<?php echo base_url() ?>member/logout"><i class="fa fa-power-off"></i>
                                    Logout</a></li>
                        </ul>
                    </div>
                </li>
            </ul>
        </div>
    </nav>
</header>