
<aside class="left-sidebar">
    <div class="scroll-sidebar">
        <nav class="sidebar-nav">
            <ul id="sidebarnav">

                <li class="nav-small-cap">--- DASHBOARD ---</li>

                <li class="<?php echo ($page == 'dashboard' ? 'active' : '')?>">
                    <a class="waves-effect waves-dark" href="<?php echo base_url('member/dashboard') ?>" aria-expanded="false"><i class="icon-Home"></i>
                        <span class="hide-menu">
                           Dashboard
                        </span>
                    </a>
                </li>

                <li class="<?php echo ($page == 'wallet' ? 'active' : '')?>">
                    <a class="waves-effect waves-dark" href="<?php echo base_url('member/wallet') ?>" aria-expanded="false"><i class="icon-Wallet"></i>
                        <span class="hide-menu">
                           My Wallet
                        </span>
                    </a>
                </li>

                <li class="nav-small-cap">--- MEMBERSHIP ---</li>

                <li class="<?php echo ($page == 'print_card' ? 'active' : '')?>">
                    <a class="waves-effect waves-dark" href="<?php echo base_url('member/print_card') ?>" aria-expanded="false">
                        <i class="icon-Printer"></i>
                        <span class="hide-menu">
                           Print Card
                        </span>
                    </a>
                </li>

                <li class="<?php echo ($page == 'upgrade' ? 'active' : '')?>">
                    <a class="waves-effect waves-dark" href="<?php echo base_url('member/upgrade') ?>" aria-expanded="false">
                        <i class="icon-Upgrade"></i>
                        <span class="hide-menu">
                           Upgrade / Renew
                        </span>
                    </a>
                </li>

                <li class="nav-small-cap">--- PARTICIPATE ---</li>

                <li class="<?php echo ($page == 'donate' ? 'active' : '')?>">
                    <a class="waves-effect waves-dark" href="<?php echo base_url('member/donate') ?>" aria-expanded="false">
                        <i class="icon-Money"></i>
                        <span class="hide-menu">
                          Donate
                        </span>
                    </a>
                </li>

                <li class="<?php echo ( $page == 'subscriptions' ? 'active' : '')?>">
                    <a class="waves-effect waves-dark" href="<?php echo base_url('member/subscriptions') ?>" aria-expanded="false">
                        <i class="icon-Shop"></i>
                        <span class="hide-menu">
                            Subscriptions
                        </span>
                    </a>
                </li>

                <li class="<?php echo ($page == 'tweets' ? 'active' : '')?>">
                    <a class="waves-effect waves-dark" href="<?php echo base_url('member/tweets') ?>" aria-expanded="false"><i class="icon-Twitter"></i>
                        <span class="hide-menu">
                          ODM Tweets
                        </span>
                    </a>
                </li>

                <li class="nav-small-cap">--- SETTINGS ---</li>

                <li class="<?php echo ($page == 'profile' ? 'active' : '')?>">
                    <a class="waves-effect waves-dark" href="<?php echo base_url('member/profile') ?>" aria-expanded="false">
                        <i class="icon-User"></i>
                        <span class="hide-menu">
                          My Profile
                        </span>
                    </a>
                </li>

            </ul>
        </nav>
    </div>

</aside>


<div class="page-wrapper">