<section id="wrapper" style="height: 100vh;">
    <div class="container">
        <div class="row">
            <div class="col-sm-4"></div>
            <div class="col-sm-4">
                <div style="margin-top: 1vh;">
                    <div style="margin-right: auto; margin-left: auto; display: block; width: 250px; height: 150px;">
                        <img src="<?php echo base_url() ;?>assets/images/logo.png" alt="odm logo" class="img-responsive" style="width:100%; height: 100%;" />
                    </div>
                    <h4 class="text-center">
                        Login
                    </h4>
                    <hr>
                    <div class="card">
                        <div class="card-body">
                            <form class="form-horizontal" method="post" id="login_form" action="<?php echo base_url('auth/login_action')?>">
                                <div class="alert alert-danger" id="wrong_details" style="display: none;">
                                    Incorrect Credentials. Try Again.
                                </div>
                                <div class="form-group m-t-40">
                                    <div class="col-xs-12">
                                        <label for="auth_doc_login">
                                            Identification Document
                                        </label>
                                        <select class="form-control select2" name="doc_type" required id="auth_doc_login">
                                            <option value="">--- Add Document ---</option>
                                            <?php foreach ($documents as $document) {?>
                                                <option value="<?php echo $document->id?>">
                                                    <?php echo ucwords(strtolower($document->doc_name), " ")?>
                                                </option>
                                            <?php }?>
                                        </select>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="col-xs-12">
                                        <label for="doc_number">
                                            ID / Passport Number
                                        </label>
                                        <input type="number" id="doc_no_login" name="doc_no" class="form-control" required>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="col-xs-12">
                                        <label for="password">
                                            Password
                                        </label>
                                        <input type="password" id="password_login" name="password" class="form-control" required>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <div class="col-8">
                                        <label for="sec_type">
                                            Security Code
                                        </label>
                                        <input type="number" class="form-control" id="sec_code" name="sec_code" required>
                                        <span class="help-block">
                                            <i>
                                                <b>
                                                    <b>
                                                        Click get code button
                                                    </b>
                                                </b>
                                            </i>
                                        </span>
                                    </div>
                                    <div class="col-4">
                                        <button type="button" class="btn btn-warning btn-sm" id="send_sec_code" style="margin-top: 25px;">
                                            Get Code
                                        </button>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="g-recaptcha" data-callback="recaptchaCallback"
                                         data-sitekey="6Lfv0XEUAAAAAI5X2Z36_FQlz80iTwgg37g8dcwo">
                                    </div>
                                </div>
                                <div class="form-group text-center m-t-20">
                                    <div class="col-xs-12">
                                        <button class="btn btn-warning btn-md" type="submit" id="btn-bg" style="width: 100%; display: none;">
                                            <span class="text-center" id="login_text_default">
                                                    Login &nbsp;
                                            </span>
                                            <span class="row">
                                                <span class="col-xs-10" id="login_text" style="display: none;">
                                                     &nbsp;
                                                </span>
                                                <span class="col-xs-2" id="loader_login" style="display: none;">
                                                    <img src="<?php echo base_url('assets/images/loader/loader.gif')?>" class="img-responsive" style="width: 30px; height: 30px;">
                                                </span>
                                            </span>
                                        </button>
                                    </div>
                                </div>
                                <div class="form-group m-b-0">
                                    <div class="col-sm-12 text-center">
                                        <a href="<?php echo base_url('auth/forgot_password')?>" class="text-primary m-l-5"><b>Forgot Password?</b></a>
                                        <br><br>
                                        <a href="<?php echo base_url('auth/signup')?>" class="text-primary m-l-5"><b>Don't have an account? Sign Up</b></a>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-sm-4"></div>
        </div>
    </div>
</section>
