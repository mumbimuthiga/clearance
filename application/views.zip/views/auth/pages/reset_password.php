<section id="wrapper" style="height: 100vh;">
    <div class="container">
        <div class="row">
            <div class="col-sm-4"></div>
            <div class="col-sm-4">
                <div style="margin-top: 20vh;">
                    <div style="margin-right: auto; margin-left: auto; display: block; width: 250px; height: 150px;">
                        <img src="<?php echo base_url() ;?>assets/images/logo.png" alt="odm logo" class="img-responsive" style="width:100%; height: 100%;" />
                    </div>
                    <h4 class="text-center">
                        Reset Password
                    </h4>
                    <hr>
                    <div class="card">
                        <div class="card-body">
                            <form class="form-horizontal" method="post" id="reset_pass_form" action="<?php echo base_url('auth/reset_user_password')?>">
                                <div class="alert alert-danger" id="wrong_details" style="display: none;">
                                    Incorrect Credentials. Try Again.
                                </div>
                                <div class="form-group">
                                    <label for="pass1_reg">
                                        Password
                                    </label>
                                    <input type="hidden" name="user_id" value="<?php echo $this->uri->segment(3) ;?>">
                                    <input type="password" class="form-control" id="pass1_reg" name="pass1" required oninput="check_pass1()">
                                    <span class="help-block" id="pass1_error" style="display: none; color: red">
                                                Password must be at least 8 characters long
                                            </span>
                                </div>
                                <div class="form-group">
                                    <label for="pass2_reg">
                                        Confirm Password
                                    </label>
                                    <input type="password" class="form-control" id="pass2_reg" name="pass2" required oninput="check_pass2()">
                                    <span class="help-block" id="pass_mismatch" style="display: none; color: red">
                                                Passwords do not match
                                            </span>
                                </div>
                                <div class="form-group text-center m-t-20">
                                    <div class="col-xs-12">
                                        <button class="btn btn-warning btn-md" type="submit" style="width: 100%;">
                                            Reset Password
                                        </button>
                                    </div>
                                </div>
                                <div class="form-group m-b-0">
                                    <hr>
                                    <div class="col-sm-12 text-center">
                                        <a href="<?php echo base_url('auth/signup')?>" class="text-primary m-l-5"><b>Don't have an account? Sign Up</b></a>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-sm-4"></div>
        </div>
    </div>
</section>
