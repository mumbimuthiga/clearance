<section id="wrapper" style="height: 100vh;">
    <div class="container">
        <div class="row">
            <div class="col-sm-2"></div>
            <div class="col-sm-8">
                <div style="margin-top: 1vh;">
                    <div style="margin-right: auto; margin-left: auto; display: block; width: 250px; height: 150px;">
                        <img src="<?php echo base_url() ;?>assets/images/logo.png" alt="odm logo" class="img-responsive" style="width:100%; height: 100%;" />
                    </div>
                    <h4 class="text-center">
                        Verify Account
                    </h4>
                    <hr>
                    <div class="card">
                        <div class="card-body">
                            <form class="form-horizontal" method="post" id="verify_account" action="<?php echo base_url('auth/verify_account')?>">
                                <div class="row">
                                    <div class="col-sm-6" style="border-right: solid 1px lightgrey">
                                        <div class="form-group">
                                            <label for="fname">
                                                First Name &nbsp; <span style="color: red;">*</span>
                                            </label>
                                            <input type="text" class="form-control" id="fname" name="fname" required>
                                        </div>
                                        <div class="form-group">
                                            <label for="other_names">
                                                Other Names
                                            </label>
                                            <input type="text" class="form-control" id="other_names" name="other_names">
                                        </div>
                                        <div class="form-group">
                                            <label for="phone">
                                                Phone Number &nbsp; <span style="color: red;">*</span>
                                            </label>
                                            <input type="number" class="form-control" id="phone" name="phone" required  placeholder="e.g 07xxxxxxxx">
                                        </div>
                                        <div class="form-group">
                                            <label for="doc_no">
                                                ID / PassPort No. &nbsp; <span style="color: red;">*</span>
                                            </label>
                                            <input type="number" class="form-control" id="doc_no" name="doc_no" required>
                                        </div>
                                    </div>
                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label for="gender">
                                                Gender &nbsp; <span style="color: red;">*</span>
                                            </label>
                                            <select id="gender" class="form-control select2" name="gender" required>
                                                <option value="">--- Add Gender ---</option>
                                                <?php foreach ($gender as $value) {?>
                                                    <option value="<?php echo $value->id?>">
                                                        <?php echo $value->gender ;?>
                                                    </option>
                                                <?php }?>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label for="county">
                                                County &nbsp; <span style="color: red;">*</span>
                                            </label>
                                            <select class="form-control select2" name="county" required id="county" onchange="get_constituencies()">
                                                <option value="">--- Add County ---</option>
                                                <?php foreach ($counties as $county) {?>
                                                    <option value="<?php echo $county->id?>">
                                                        <?php echo ucwords(strtolower($county->name), " ")?>
                                                    </option>
                                                <?php }?>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label for="constituency">
                                                Constituencies &nbsp; <span style="color: red;">*</span>
                                            </label>
                                            <select class="form-control select2" name="constituency" required id="constituency" onchange="get_wards()">
                                                <option value="">--- Add Constituency ---</option>
                                                <?php foreach ($constituencies as $constituency) {?>
                                                    <option value="<?php echo $constituency->id?>">
                                                        <?php echo ucwords(strtolower($constituency->name), " ")?>
                                                    </option>
                                                <?php }?>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label for="wards">
                                                Ward &nbsp; <span style="color: red;">*</span>
                                            </label>
                                            <select class="form-control select2" name="ward" required id="wards">
                                                <option value="">--- Add Ward ---</option>
                                                <?php foreach ($wards as $ward) {?>
                                                    <option value="<?php echo $ward->id?>">
                                                        <?php echo ucwords(strtolower($ward->name), " ")?>
                                                    </option>
                                                <?php }?>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-6">
                                        <hr>
                                        <div class="form-group">
                                            <div class="g-recaptcha" data-callback="recaptchaCallbackVerify"
                                                 data-sitekey="6Lfv0XEUAAAAAI5X2Z36_FQlz80iTwgg37g8dcwo">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-6">
                                        <hr>
                                        <div class="form-group">
                                            <button class="btn btn-warning btn-md" type="submit" id="verify_btn_bg" style="width: auto; display: none; margin-top: 15px;">
                                                <span class="text-center" id="login_text_default">
                                                        Verify Account &nbsp;
                                                </span>
                                                <span class="row">
                                                <span class="col-xs-10" id="login_text" style="display: none;">
                                                     &nbsp;
                                                </span>
                                                <span class="col-xs-2" id="loader_login" style="display: none;">
                                                    <img src="<?php echo base_url('assets/images/loader/loader.gif')?>" class="img-responsive" style="width: 30px; height: 30px;">
                                                </span>
                                            </span>
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-sm-2"></div>
        </div>
    </div>
</section>
