<section id="wrapper" style="height: 100vh;">
    <div class="container">
        <div class="row">
            <div class="col-sm-12">
                <div style="margin-top: 1vh;">
                    <div style="margin-right: auto; margin-left: auto; display: block; width: 250px; height: 150px;">
                        <img src="<?php echo base_url() ;?>assets/images/logo.png" alt="odm logo" class="img-responsive" style="width:100%; height: 100%;" />
                    </div>
                    <h4 class="text-center">
                       Register
                    </h4>
                    <hr>
                    <div class="card">
                        <div class="card-body">
                            <form class="form-horizontal" method="post" id="registration_form" action="<?php echo base_url('auth/reg_action')?>">
                                <div class="row">
                                    <div class="col-sm-4" style="border-right: solid 1px lightgrey">
                                        <div class="form-group">
                                            <label for="fname_reg">
                                                First Name &nbsp; <span style="color: red;">*</span>
                                            </label>
                                            <input type="text" class="form-control" id="fname_reg" name="fname" required oninput="check_fname()">
                                            <span class="help-block" id="fname_error" style="display: none; color: red">
                                                First name must be letters only
                                            </span>
                                        </div>
                                        <div class="form-group">
                                            <label for="other_names_reg">
                                                Other Names &nbsp; <span style="color: red;">*</span>
                                            </label>
                                            <input type="text" class="form-control" id="other_names_reg" name="other_names" required oninput="check_other_names()">
                                            <span class="help-block" id="other_names_error" style="display: none; color: red">
                                                Other names must be letters only
                                            </span>
                                        </div>
                                        <div class="form-group">
                                            <label for="email_reg">
                                                Email Address &nbsp; <span style="color: red;">*</span>
                                            </label>
                                            <input type="email" class="form-control" id="email_reg" name="email" required oninput="check_email()">
                                            <span class="help-block" id="email_error" style="display: none; color: red">
                                                Enter correct email address
                                            </span>
                                        </div>
                                        <div class="form-group">
                                            <label for="phone_reg">
                                                Phone Number &nbsp; <span style="color: red;">*</span>
                                            </label>
                                            <input type="number" class="form-control" id="phone_reg" name="phone" required placeholder="e.g 07xxxxxxxx" oninput="check_phone()">
                                            <span class="help-block" id="phone_error" style="display: none; color: red">
                                                Phone number must be 10 characters long
                                            </span>
                                        </div>
                                        <div class="form-group">
                                            <label for="gender">
                                                Gender &nbsp; <span style="color: red;">*</span>
                                            </label>
                                            <select id="gender" class="form-control select2" name="gender" required>
                                                <option value="">--- Add Gender ---</option>
                                                <?php foreach ($gender as $value) {?>
                                                    <option value="<?php echo $value->id?>">
                                                        <?php echo $value->gender ;?>
                                                    </option>
                                                <?php }?>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label for="religion">
                                                Religion &nbsp; <span style="color: red;">*</span>
                                            </label>
                                            <select id="religion" class="form-control select2" name="religion" required>
                                                <option value="">--- Add Religion ---</option>
                                                <option value="Christian">Christian</option>
                                                <option value="Islam">Islam</option>
                                                <option value="Hindu">Hindu</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-sm-4" style="border-right: solid 1px lightgrey">
                                        <div class="form-group">
                                            <label for="visitor_date">
                                                Date of Birth &nbsp; <span style="color: red;">*</span>
                                            </label>
                                            <input type="text" class="form-control" name="dob" id="visitor_date" required autocomplete="off">
                                        </div>
                                        <div class="form-group">
                                            <label for="doc_type">
                                                Identification Document &nbsp; <span style="color: red;">*</span>
                                            </label>
                                            <select class="form-control select2" name="doc_type" required id="doc_type">
                                                <option value="">--- Add Document ---</option>
                                                <?php foreach ($documents as $document) {?>
                                                    <option value="<?php echo $document->id?>">
                                                        <?php echo ucwords(strtolower($document->doc_name), " ")?>
                                                    </option>
                                                <?php }?>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label for="idno">
                                                ID / Passport Number &nbsp; <span style="color: red;">*</span>
                                            </label>
                                            <input type="number" class="form-control" id="idno" name="doc_id" required>
                                        </div>
                                        <div class="form-group">
                                            <label for="iebc_v_no">
                                                IEBC Voters Number
                                            </label>
                                            <input type="number" class="form-control" id="iebc_v_no" name="voters_no" >
                                        </div>
                                        <div class="form-group">
                                            <label for="interest_groups">
                                                Interest Groups &nbsp; <span style="color: red;">*</span>
                                            </label>
                                            <!--<select class="form-control select2" name="interest_groups" required id="interest_groups">-->
                                            <select class="select2 m-b-10 select2-multiple" style="width: 100%" multiple="multiple" data-placeholder="Choose" name="interest_groups[]" required id="interest_groups">
                                                <option value="">--- Add Group ---</option>
                                                <?php foreach ($groups as $group) {?>
                                                    <option value="<?php echo $group->id?>">
                                                        <?php echo ucwords(strtolower($group->name), " ")?>
                                                    </option>
                                                <?php }?>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label for="county">
                                                County &nbsp; <span style="color: red;">*</span>
                                            </label>
                                            <select class="form-control select2" name="county" required id="county" onchange="get_constituencies()">
                                                <option value="">--- Add County ---</option>
                                                <?php foreach ($counties as $county) {?>
                                                    <option value="<?php echo $county->id?>">
                                                        <?php echo ucwords(strtolower($county->name), " ")?>
                                                    </option>
                                                <?php }?>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-sm-4">
                                        <div class="form-group">
                                            <label for="constituency">
                                                Constituencies &nbsp; <span style="color: red;">*</span>
                                            </label>
                                            <select class="form-control select2" name="constituency" required id="constituency" onchange="get_wards()">
                                                <option value="">--- Add Constituency ---</option>
                                                <?php /*foreach ($constituencies as $constituency) {*/?><!--
                                                    <option value="<?php /*echo $constituency->id*/?>">
                                                        <?php /*echo ucwords(strtolower($constituency->name), " ")*/?>
                                                    </option>
                                                --><?php /*}*/?>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label for="wards">
                                                Ward &nbsp; <span style="color: red;">*</span>
                                            </label>
                                            <select class="form-control select2" name="ward" required id="wards" onchange="get_polling_stations()">
                                                <option value="">--- Add Ward ---</option>
                                                <?php /*foreach ($wards as $ward) {*/?><!--
                                                    <option value="<?php /*echo $ward->id*/?>">
                                                        <?php /*echo ucwords(strtolower($ward->name), " ")*/?>
                                                    </option>
                                                --><?php /*}*/?>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label for="polling">
                                                Polling Station &nbsp; <span style="color: red;">*</span>
                                            </label>
                                            <select class="form-control select2" name="p_station" required id="polling">
                                                <option value="">--- Add Polling Station ---</option>
                                                <?php /*foreach ($polling_stations as $station) {*/?><!--
                                                    <option value="<?php /*echo $station->id*/?>">
                                                        <?php /*echo ucwords(strtolower($station->name), " ")*/?>
                                                    </option>
                                                --><?php /*}*/?>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label for="pass1_reg">
                                                Password &nbsp; <span style="color: red;">*</span>
                                            </label>
                                            <input type="password" class="form-control" id="pass1_reg" name="pass1" required oninput="check_pass1()">
                                            <span class="help-block" id="pass1_error" style="display: none; color: red">
                                                Password must be at least 8 characters long
                                            </span>
                                        </div>
                                        <div class="form-group">
                                            <label for="pass2_reg">
                                                Confirm Password &nbsp; <span style="color: red;">*</span>
                                            </label>
                                            <input type="password" class="form-control" id="pass2_reg" name="pass2" required oninput="check_pass2()">
                                            <span class="help-block" id="pass_mismatch" style="display: none; color: red">
                                                Passwords do not match
                                            </span>
                                        </div>
                                        <div class="form-group">
                                            <div class="g-recaptcha" data-callback="recaptchaCallbackSignup"
                                                 data-sitekey="6Lfv0XEUAAAAAI5X2Z36_FQlz80iTwgg37g8dcwo">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-12">
                                        <hr>
                                        <div class="form-group text-center m-t-20">
                                            <div class="col-xs-12">
                                                <button class="btn btn-warning btn-md" type="submit" id="reg_btn_bg" style="width: auto; display: none;">
                                                    <span class="text-center" id="login_text_default">
                                                            Create Account &nbsp;
                                                    </span>
                                                </button>
                                            </div>
                                        </div>
                                        <div class="form-group m-b-0">
                                            <div class="col-sm-12 text-center">
                                                <a href="<?php echo base_url('auth/login')?>" class="text-primary m-l-5"><b>Already have an account? Login</b></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
