<section id="wrapper" style="height: 100vh;">
    <div class="container">
        <div class="row">
            <div class="col-sm-3"></div>
            <div class="col-sm-6">
                <div style="margin-top: 20vh;">
                    <div style="margin-right: auto; margin-left: auto; display: block; width: 250px; height: 150px;">
                        <img src="<?php echo base_url() ;?>assets/images/logo.png" alt="odm logo" class="img-responsive" style="width:100%; height: 100%;" />
                    </div>
                    <h4 class="text-center">
                        Verification Code
                    </h4>
                    <hr>
                    <div class="card">
                        <div class="card-body">
                            <form class="form-horizontal" method="post" id="verification_form" action="<?php echo base_url('auth/verify_code')?>">
                                <div class="form-group">
                                    <div class="col-xs-12">
                                        <label for="v_code">
                                            Enter Verification code
                                        </label>
                                        <input type="hidden" name="user_id" value="<?php echo $user_id ;?>">
                                        <input type="number" id="v_code" name="v_code" class="form-control" required>
                                    </div>
                                </div>
                                <div class="form-group text-center m-t-20">
                                    <div class="col-xs-12">
                                        <button class="btn btn-warning btn-md" type="submit" id="btn-bg" style="width: 100%;">
                                            <span class="text-center" id="login_text_default">
                                                    Verify Code &nbsp;
                                            </span>
                                        </button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-sm-3"></div>
        </div>
    </div>
</section>
