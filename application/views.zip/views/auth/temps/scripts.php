<script src="<?php echo base_url() ;?>assets/node_modules/jquery/jquery.min.js"></script>
<script src="<?php echo base_url() ;?>assets/node_modules/bootstrap/js/popper.min.js"></script>
<script src="<?php echo base_url() ;?>assets/node_modules/bootstrap/js/bootstrap.min.js"></script>
<script src="<?php echo base_url()?>assets/node_modules/select2/dist/js/select2.full.min.js" type="text/javascript"></script>
<script src="<?php echo base_url()?>assets/node_modules/bootstrap-select/bootstrap-select.min.js" type="text/javascript"></script>
<script type="text/javascript" src="<?php echo base_url()?>assets/node_modules/multiselect/js/jquery.multi-select.js"></script>
<script src="<?php echo base_url()?>assets/node_modules/sweetalert/sweetalert.min.js"></script>

<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>

<script src="<?php echo base_url() ;?>assets/external/custom.js"></script>

<script type="text/javascript">
    $(function() {
        $(".preloader").fadeOut();
    });
    $(function() {
        $('[data-toggle="tooltip"]').tooltip()
    });
    $('#to-recover').on("click", function() {
        $("#loginform").slideUp();
        $("#recoverform").fadeIn();
    });
</script>

<script src='https://www.google.com/recaptcha/api.js'></script>
<script type="text/javascript">
    window.base_url = "<?php echo base_url(); ?>";
    var pakage_type = "";
    var phn = "";

    function recaptchaCallback()
    {
        $("#btn-bg").fadeIn(1000);
    }
</script>

<script type="text/javascript">
    function recaptchaCallbackSignup()
    {
        $("#reg_btn_bg").fadeIn(1000);
    }
</script>

<script type="text/javascript">
    function recaptchaCallbackVerify()
    {
        $("#verify_btn_bg").fadeIn(1000);
    }
</script>


</body>

</html>