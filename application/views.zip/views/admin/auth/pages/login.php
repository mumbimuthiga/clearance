<section id="wrapper" style="height: 100vh;">
    <div class="container">
        <div class="row">
            <div class="col-sm-4"></div>
            <div class="col-sm-4">
                <div style="margin-top: 20vh;">
                    <div style="margin-right: auto; margin-left: auto; display: block; width: 250px; height: 150px;">
                        <img src="<?php echo base_url() ;?>assets/images/logo.png" alt="odm logo" class="img-responsive" style="width:100%; height: 100%;" />
                    </div>
                    <div class="card">
                        <div class="card-body">
                            <form class="form-horizontal" method="post" id="login_form_admin" action="<?php echo base_url('admin/login_action')?>">
                                <div class="alert alert-danger" id="wrong_details" style="display: none;">
                                    Incorrect Credentials. Try Again.
                                </div>
                                <div class="form-group">
                                    <div class="col-xs-12">
                                        <label for="email_admin">
                                            Email Address
                                        </label>
                                        <input type="email" id="email_admin" name="email" class="form-control" required>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="col-xs-12">
                                        <label for="password_admin">
                                            Password
                                        </label>
                                        <input type="password" id="password_admin" name="password" class="form-control" required>
                                    </div>
                                </div>
                                <div class="form-group text-center m-t-20">
                                    <div class="col-xs-12">
                                        <button class="btn btn-warning btn-md" type="submit" id="btn-bg" style="width: 100%;">
                                            Login &nbsp;
                                        </button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-sm-4"></div>
        </div>
    </div>
</section>
