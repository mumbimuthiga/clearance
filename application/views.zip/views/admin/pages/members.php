<div class="container-fluid">
    <?php $this->load->view('admin/pages/head_info') ;?>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body p-b-0">
                    <div class="row">
                        <div class="col-sm-3" id="support_issues_border">
                            <br>
                            <h5>
                                Filter Search
                            </h5>
                            <hr>
                            <form method="post" action="<?php echo base_url('admin/search_user/members')?>">
                                <div class="form-group">
                                    <label for="interest_groups">
                                        Interest Groups
                                    </label>
                                    <select class="select2 m-b-10 select2-multiple" style="width: 100%" multiple="multiple" data-placeholder="Choose" name="interest_groups[]" id="interest_groups">
                                        <option value="">--- Add Group ---</option>
                                        <?php foreach ($groups as $group) {?>
                                            <option value="<?php echo $group->id?>" <?php echo (in_array($group->id, $group_s) ? 'selected' : '')?> >
                                                <?php echo ucwords(strtolower($group->name), " ")?>
                                            </option>
                                        <?php }?>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="gender">
                                        Gender
                                    </label>
                                    <select id="gender" class="form-control select2" name="gender">
                                        <option value="">All</option>
                                        <?php foreach ($gender as $value) {?>
                                            <option value="<?php echo $value->id?>" <?php echo ($value->id == $sex ? 'selected' : '')?>>
                                                <?php echo $value->gender ;?>
                                            </option>
                                        <?php }?>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="county">
                                        County
                                    </label>
                                    <select class="form-control select2" name="county" id="county" onchange="get_constituencies()">
                                        <option value="">--- Add County ---</option>
                                        <?php foreach ($counties as $county) {?>
                                            <option value="<?php echo $county->id?>" <?php echo ($county->id == $county_s ? 'selected' : '')?> >
                                                <?php echo ucwords(strtolower($county->name), " ")?>
                                            </option>
                                        <?php }?>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="constituency">
                                        Constituency
                                    </label>
                                    <select class="form-control select2" name="constituency" id="constituency" onchange="get_wards()">
                                        <option value="">--- Add Constituency ---</option>
                                        <?php foreach ($all_const as $value) {?>
                                            <option value="<?php echo $value->id?>" <?php echo ($value->id == $constituency_s ? 'selected' : '')?> >
                                                <?php echo ucwords(strtolower($value->name), " ")?>
                                            </option>
                                        <?php }?>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="wards">
                                        Ward
                                    </label>
                                    <select class="form-control select2" name="ward" id="wards">
                                        <option value="">--- Add Ward ---</option>
                                        <?php foreach ($all_wards as $value) {?>
                                            <option value="<?php echo $value->id?>" <?php echo ($value->id == $ward_s ? 'selected' : '')?> >
                                                <?php echo ucwords(strtolower($value->name), " ")?>
                                            </option>
                                        <?php }?>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <button class="btn btn-inverse" id="btn-bg" style="width: 100%">
                                        <i class="fa fa-search"></i>
                                        &nbsp;
                                        Search
                                    </button>
                                </div>
                            </form>
                        </div>
                        <div class="col-sm-9" id="support_issues_border">
                            <div class="card">
                                <div class="card-body">
                                    <?php if($this->uri->segment(3) == '') {?>
                                        <div class="row">
                                            <div class="col-sm-3"></div>
                                            <div class="col-sm-6">
                                                <div style="margin-top: 25vh; text-align: center;">
                                                    <h5>
                                                        Please Filter your search
                                                    </h5>
                                                </div>
                                            </div>
                                            <div class="col-sm-3"></div>
                                        </div>
                                    <?php } else {?>
                                        <div class="row">
                                            <div class="col-sm-12">
                                                <h5>
                                                    Search Results &nbsp;(<b><?php echo count($results)?></b>)
                                                </h5>
                                            </div>
                                        </div>
                                        <hr>
                                        <div class="table-responsive">
                                            <table id="myTable" class="table table-bordered table-striped">
                                                <thead>
                                                <tr>
                                                    <th> Name </th>
                                                    <th> Gender</th>
                                                    <th> County</th>
                                                    <th> Constituency</th>
                                                    <th> Ward</th>
                                                    <th>Actions</th>
                                                </tr>
                                                </thead>
                                                <tbody>
                                                <?php foreach ($results as $result) {?>
                                                    <?php
                                                    $user_county = $this->User_model->get_county($result->county);
                                                    $user_constituency = $this->User_model->get_constituency($result->constituency);
                                                    $user_ward = $this->User_model->get_ward($result->ward);
                                                    $user_gender = $this->User_model->get_gender($result->sex);
                                                    ?>
                                                    <tr>
                                                        <td>
                                                            <input type="hidden" name="user_id[]" value="<?php echo $result->user_id?>">
                                                            <?php echo ucwords(strtolower($result->fname." ".$result->other_names), " ")?>
                                                        </td>
                                                        <td>
                                                            <?php echo ucfirst(strtolower($user_gender))?>
                                                        </td>
                                                        <td>
                                                            <?php echo ucfirst(strtolower($user_county))?>
                                                        </td>
                                                        <td>
                                                            <?php echo ucfirst(strtolower($user_constituency))?>
                                                        </td>
                                                        <td>
                                                            <?php echo ucfirst(strtolower($user_ward))?>
                                                        </td>
                                                        <td>
                                                            <ul class="list-inline">
                                                                <li>
                                                                    <a target="_blank" href="<?php echo base_url('admin/view_member/'.$result->user_id)?>" class="btn btn-inverse btn-sm">
                                                                        View Details
                                                                    </a>
                                                                </li>
                                                                <li>
                                                                    <button class="btn btn-outline-success btn-sm" onclick="terminate_user('<?php echo $result->user_id?>', '<?php echo $result->id?>')">
                                                                        Terminate
                                                                    </button>
                                                                </li>
                                                                <li>
                                                                    &nbsp;
                                                                    <i class="fa fa-times-circle" id="check_two<?php echo $result->id?>" style="color: red; font-size: 16px; display: <?php echo ($result->active > 0 ? '' : 'none')?>;"></i>
                                                                </li>
                                                            </ul>
                                                        </td>
                                                    </tr>
                                                <?php }?>
                                                </tbody>
                                                <tfoot>
                                                <tr>
                                                    <th> Name </th>
                                                    <th> Gender</th>
                                                    <th> County</th>
                                                    <th> Constituency</th>
                                                    <th> Ward</th>
                                                    <th> Actions</th>
                                                </tr>
                                                </tfoot>
                                            </table>
                                        </div>
                                    <?php }?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php /*$this->load->view('user/pages/social_links')*/?>
    </div>
</div>
