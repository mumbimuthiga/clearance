<div class="container-fluid">
    <?php $this->load->view('admin/pages/head_info') ;?>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body p-b-0">
                    <div class="row">
                        <div class="col-sm-3" id="support_issues_border">
                            <br>
                            <h5>
                                Filter Search
                            </h5>
                            <hr>
                            <form method="post" action="<?php echo base_url('admin/search_user/email')?>">
                                <div class="form-group">
                                    <label for="interest_groups">
                                        Interest Groups
                                    </label>
                                    <select class="select2 m-b-10 select2-multiple" style="width: 100%" multiple="multiple" data-placeholder="Choose" name="interest_groups[]" id="interest_groups">
                                        <option value="">--- Add Group ---</option>
                                        <?php foreach ($groups as $group) {?>
                                            <option value="<?php echo $group->id?>" <?php echo (in_array($group->id, $group_s) ? 'selected' : '')?> >
                                                <?php echo ucwords(strtolower($group->name), " ")?>
                                            </option>
                                        <?php }?>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="gender">
                                        Gender
                                    </label>
                                    <select id="gender" class="form-control select2" name="gender">
                                        <option value="">All</option>
                                        <?php foreach ($gender as $value) {?>
                                            <option value="<?php echo $value->id?>" <?php echo ($value->id == $sex ? 'selected' : '')?>>
                                                <?php echo $value->gender ;?>
                                            </option>
                                        <?php }?>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="county">
                                        County
                                    </label>
                                    <select class="form-control select2" name="county" id="county" onchange="get_constituencies()">
                                        <option value="">--- Add County ---</option>
                                        <?php foreach ($counties as $county) {?>
                                            <option value="<?php echo $county->id?>" <?php echo ($county->id == $county_s ? 'selected' : '')?> >
                                                <?php echo ucwords(strtolower($county->name), " ")?>
                                            </option>
                                        <?php }?>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="constituency">
                                        Constituency
                                    </label>
                                    <select class="form-control select2" name="constituency" id="constituency" onchange="get_wards()">
                                        <option value="">--- Add Constituency ---</option>
                                        <?php foreach ($all_const as $value) {?>
                                            <option value="<?php echo $value->id?>" <?php echo ($value->id == $constituency_s ? 'selected' : '')?> >
                                                <?php echo ucwords(strtolower($value->name), " ")?>
                                            </option>
                                        <?php }?>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="wards">
                                        Ward
                                    </label>
                                    <select class="form-control select2" name="ward" id="wards">
                                        <option value="">--- Add Ward ---</option>
                                        <?php foreach ($all_wards as $value) {?>
                                            <option value="<?php echo $value->id?>" <?php echo ($value->id == $ward_s ? 'selected' : '')?> >
                                                <?php echo ucwords(strtolower($value->name), " ")?>
                                            </option>
                                        <?php }?>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <button class="btn btn-inverse" id="btn-bg" style="width: 100%">
                                        <i class="fa fa-search"></i>
                                        &nbsp;
                                        Search
                                    </button>
                                </div>
                            </form>
                        </div>
                        <div class="col-sm-9" id="support_issues_border">
                            <div class="card">
                                <div class="card-body">
                                    <?php if($this->uri->segment(3) == '') {?>
                                        <div class="row">
                                            <div class="col-sm-3"></div>
                                            <div class="col-sm-6">
                                                <div style="margin-top: 25vh; text-align: center;">
                                                    <h5>
                                                        Please Filter your search
                                                    </h5>
                                                </div>
                                            </div>
                                            <div class="col-sm-3"></div>
                                        </div>
                                    <?php } else {?>
                                        <form id="emails_form" method="post" action="<?php echo base_url('admin/send_member_emails')?>">
                                            <div class="row">
                                                <div class="col-12">
                                                    <div class="modal fade" id="emailModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                                        <div class="modal-dialog" role="document">
                                                            <div class="modal-content">
                                                                <div class="modal-header">
                                                                    <h5 class="modal-title" id="exampleModalLabel">Compose Email</h5>
                                                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                        <span aria-hidden="true">&times;</span>
                                                                    </button>
                                                                </div>
                                                                <div class="modal-body">
                                                                    <div class="form-group">
                                                                        <label for="email_subject">
                                                                            Subject
                                                                        </label>
                                                                        <input type="text" class="form-control" name="subject" required id="email_subject">
                                                                    </div>
                                                                    <div class="form-group">
                                                                        <label for="email_body">
                                                                            Message
                                                                        </label>
                                                                        <textarea class="form-control" name="message" id="email_body" rows="6" required></textarea>
                                                                    </div>
                                                                </div>
                                                                <div class="modal-footer">
                                                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                                                    <button type="submit" class="btn btn-inverse">Send Email</button>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-sm-10">
                                                    <h5>
                                                        Search Results &nbsp;(<b><?php echo count($results)?></b>)
                                                    </h5>
                                                </div>
                                                <div class="col-sm-2">
                                                    <button class="btn btn-inverse btn-sm" type="button" data-toggle="modal" data-target="#emailModal">
                                                        Send Email (s)
                                                    </button>
                                                </div>
                                            </div>
                                            <hr>
                                            <div class="table-responsive">
                                                <table id="myTable" class="table table-bordered table-striped">
                                                    <thead>
                                                    <tr>
                                                        <th> Name </th>
                                                        <th> Gender</th>
                                                        <th> County</th>
                                                        <th> Constituency</th>
                                                        <th> Ward</th>
                                                    </tr>
                                                    </thead>
                                                    <tbody>
                                                    <?php foreach ($results as $result) {?>
                                                        <?php
                                                        $user_county = $this->User_model->get_county($result->county);
                                                        $user_constituency = $this->User_model->get_constituency($result->constituency);
                                                        $user_ward = $this->User_model->get_ward($result->ward);
                                                        $user_gender = $this->User_model->get_gender($result->sex);
                                                        ?>
                                                        <tr>
                                                            <td>
                                                                <input type="hidden" name="user_id[]" value="<?php echo $result->user_id?>">
                                                                <?php echo ucwords(strtolower($result->fname." ".$result->other_names), " ")?>
                                                            </td>
                                                            <td>
                                                                <?php echo ucfirst(strtolower($user_gender))?>
                                                            </td>
                                                            <td>
                                                                <?php echo ucfirst(strtolower($user_county))?>
                                                            </td>
                                                            <td>
                                                                <?php echo ucfirst(strtolower($user_constituency))?>
                                                            </td>
                                                            <td>
                                                                <?php echo ucfirst(strtolower($user_ward))?>
                                                            </td>
                                                        </tr>
                                                    <?php }?>
                                                    </tbody>
                                                    <tfoot>
                                                    <tr>
                                                        <th> Name </th>
                                                        <th> Gender</th>
                                                        <th> County</th>
                                                        <th> Constituency</th>
                                                        <th> Ward</th>
                                                    </tr>
                                                    </tfoot>
                                                </table>
                                            </div>
                                        </form>
                                    <?php }?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php /*$this->load->view('user/pages/social_links')*/?>
    </div>
</div>
