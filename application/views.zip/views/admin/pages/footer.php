<footer class="footer">
    &copy; <?php echo date('Y') ;?> ODM <a href="https://e-kodi.com" target="_blank">Members Management System</a>
</footer>