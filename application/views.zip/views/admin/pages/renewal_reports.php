<style>
    #chartdiv_renewal_fee_growth {
        width		: 100%;
        height		: 360px;
        font-size	: 11px;
    }

    #chartdiv_renewal_growth {
        width		: 100%;
        height		: 360px;
        font-size	: 11px;
    }
</style>


<div class="container-fluid">
    <?php $this->load->view('admin/pages/head_info') ;?>
    <div class="row">
        <div class="col-md-6">
            <div class="card">
                <div class="card-body">
                    <h5>
                        Membership Renewal Fees Collection in <?php echo date('Y') ;?>
                    </h5>
                    <hr>
                    <div id="chartdiv_renewal_fee_growth"></div>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="card">
                <div class="card-body">
                    <h5>
                        Membership Renewal Growth in <?php echo date('Y') ;?>
                    </h5>
                    <hr>
                    <div id="chartdiv_renewal_growth"></div>
                </div>
            </div>
        </div>
        <?php /*$this->load->view('user/pages/social_links')*/?>
    </div>
</div>

