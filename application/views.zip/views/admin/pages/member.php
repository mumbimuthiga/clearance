<div class="container-fluid">
    <?php $this->load->view('admin/pages/head_info') ;?>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card">
                    <div class="card-body p-b-0">
                        <!-- Nav tabs -->
                        <ul class="nav nav-tabs customtab" role="tablist">
                            <li class="nav-item"> <a class="nav-link active" data-toggle="tab" href="#info" role="tab"><span class="hidden-sm-up"><i class="ti-info"></i></span> <span class="hidden-xs-down">Profile</span></a> </li>
                            <li class="nav-item"> <a class="nav-link" data-toggle="tab" href="#update" role="tab"><span class="hidden-sm-up"><i class="ti-angle-up"></i></span> <span class="hidden-xs-down">Audit Trail</span></a> </li>
                            <li class="nav-item"> <a class="nav-link" data-toggle="tab" href="#password" role="tab"><span class="hidden-sm-up"><i class="ti-money"></i></span> <span class="hidden-xs-down">Donations</span></a> </li>
                            <li class="nav-item"> <a class="nav-link" data-toggle="tab" href="#renewal" role="tab"><span class="hidden-sm-up"><i class="ti-money"></i></span> <span class="hidden-xs-down">Membership Renewal</span></a> </li>
                        </ul>
                        <div class="tab-content">
                            <div class="tab-pane active" id="info" role="tabpanel">
                                <br>
                                <h4>
                                    Profile Information
                                </h4>
                                <hr>
                                <div class="row">
                                    <div class="col-md-4">
                                        <div class="card" style="border: solid 1px lightgrey;">
                                            <div class="card-body">
                                                <div class="table-responsive">
                                                    <table class="table table-bordered table-hover table-striped" style="border: 1px solid #dee2e6 !important;">
                                                        <tr>
                                                            <th>
                                                                First Name
                                                            </th>
                                                            <td>
                                                                <?php echo ucwords(strtolower($member_details->fname), " ") ;?>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <th>
                                                                Other Names
                                                            </th>
                                                            <td>
                                                                <?php echo ucwords(strtolower($member_details->other_names), " ") ;?>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <th>
                                                                Gender
                                                            </th>
                                                            <td>
                                                                <?php

                                                                $gender = $this->User_model->get_gender($member_details->sex);

                                                                echo ucfirst($gender);
                                                                ?>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <th>
                                                                Phone Number
                                                            </th>
                                                            <td>
                                                                <?php echo $member_details->phone ;?>
                                                            </td>
                                                        </tr>

                                                        <tr>
                                                            <th>
                                                                Email Address
                                                            </th>
                                                            <td>
                                                                <?php echo $member_details->email ;?>
                                                            </td>
                                                        </tr>

                                                        <tr>
                                                            <th>
                                                                Date of Birth
                                                            </th>
                                                            <td>
                                                                <?php echo date_format(date_create($member_details->dob), 'jS F, Y') ;?>
                                                            </td>
                                                        </tr>

                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="card" style="border: solid 1px lightgrey;">
                                            <div class="card-body">
                                                <div class="table-responsive">
                                                    <table class="table table-bordered table-hover table-striped" style="border: 1px solid #dee2e6 !important;">
                                                        <tr>
                                                            <th>
                                                                Identity Doc
                                                            </th>
                                                            <td>
                                                                <?php

                                                                $doc = $this->User_model->get_identification_doc($member_details->doc_type);

                                                                echo $doc;
                                                                ?>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <th>
                                                                ID / PassPort No.
                                                            </th>
                                                            <td>
                                                                <?php echo $member_details->doc_no ;?>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <th>
                                                                Voters No.
                                                            </th>
                                                            <td>
                                                                <?php echo $member_details->voters_no ;?>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <th>
                                                                Membership No.
                                                            </th>
                                                            <td>
                                                                <?php echo $member_details->member_no ;?>
                                                            </td>
                                                        </tr>

                                                        <tr>
                                                            <th>
                                                                Interest Group
                                                            </th>
                                                            <td>

                                                                <?php

                                                                $int_groups = explode(",", $member_details->interest_group);

                                                                $interest_group = $this->User_model->get_interest_group_array($int_groups);

                                                                foreach ($interest_group as $value)
                                                                {
                                                                    echo "$value->name, ";
                                                                }

                                                                ?>

                                                            </td>
                                                        </tr>

                                                        <tr>
                                                            <th>
                                                                Religion
                                                            </th>
                                                            <td>
                                                                <?php echo $member_details->religion ;?>
                                                            </td>
                                                        </tr>

                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="card" style="border: solid 1px lightgrey;">
                                            <div class="card-body">
                                                <div class="table-responsive">
                                                    <table class="table table-bordered table-hover table-striped" style="border: 1px solid #dee2e6 !important;">
                                                        <tr>
                                                            <th>
                                                                County
                                                            </th>
                                                            <td>
                                                                <?php

                                                                $user_county = $this->User_model->get_county($member_details->county);

                                                                echo $user_county;
                                                                ?>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <th>
                                                                Constituency
                                                            </th>
                                                            <td>
                                                                <?php

                                                                $user_constituency = $this->User_model->get_constituency($member_details->constituency);

                                                                echo $user_constituency;
                                                                ?>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <th>
                                                                Ward
                                                            </th>
                                                            <td>
                                                                <?php

                                                                $user_ward = $this->User_model->get_ward($member_details->ward);

                                                                echo $user_ward;
                                                                ?>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <th>
                                                                Polling Station
                                                            </th>
                                                            <td>
                                                                <?php

                                                                $user_polling_station = $this->User_model->get_polling_station($member_details->polling_station);

                                                                echo $user_polling_station;
                                                                ?>
                                                            </td>
                                                        </tr>

                                                        <tr>
                                                            <th>
                                                                Member Type
                                                            </th>
                                                            <td>
                                                                <?php

                                                                $member_type = $this->User_model->get_membership($member_details->member_type);

                                                                echo $member_type->name;
                                                                ?>
                                                            </td>
                                                        </tr>

                                                        <tr>
                                                            <th>
                                                                Date Registered
                                                            </th>
                                                            <td>
                                                                <?php echo date_format(date_create($member_details->date), 'jS F, Y') ;?>
                                                            </td>
                                                        </tr>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <hr>
                                <div class="row">
                                    <div class="col-12">
                                        <div class="text-center">
                                            <?php if($member_details->active == 1) {?>
                                                <button class="btn btn-outline-success" onclick="activate_user('<?php echo $member_details->user_id?>')">
                                                    Activate Member
                                                </button>
                                            <?php } else {?>
                                                <button class="btn btn-outline-success" onclick="terminate_user('<?php echo $member_details->user_id?>')">
                                                    Terminate Member
                                                </button>
                                            <?php }?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="tab-pane " id="update" role="tabpanel">
                                <br>
                                <h4>
                                    Member Audit Trail
                                </h4>
                                <hr>
                                <div class="col-md-12">
                                    <div>
                                        <div class="table-responsive m-t-10">
                                            <table id="myTable2" class="table table-bordered table-striped">
                                                <thead>
                                                <tr>
                                                    <th>Type</th>
                                                    <th>Activity</th>
                                                    <th>Date Done</th>
                                                </tr>
                                                </thead>
                                                <tbody>
                                                <?php foreach ($activities as $activity) {?>
                                                    <tr>
                                                        <td>
                                                            <?php if(in_array("Donated", explode(" ", $activity->message))) {?>
                                                                Donations
                                                            <?php }?>

                                                            <?php if(in_array("in", explode(" ", $activity->message))) {?>
                                                                Sign In
                                                            <?php }?>

                                                            <?php if(in_array("out", explode(" ", $activity->message))) {?>
                                                                Sign Out
                                                            <?php }?>

                                                            <?php if(in_array("Registered", explode(" ", $activity->message))) {?>
                                                                Registration
                                                            <?php }?>

                                                            <?php if(in_array("Upgraded", explode(" ", $activity->message))) {?>
                                                                Membership Upgrade
                                                            <?php }?>

                                                            <?php if(in_array("Renewed", explode(" ", $activity->message))) {?>
                                                                Membership Renewal
                                                            <?php }?>

                                                            <?php if(in_array("Updated", explode(" ", $activity->message))) {?>
                                                                Profile Update
                                                            <?php }?>

                                                            <?php if(in_array("Wallet", explode(" ", $activity->message))) {?>
                                                                Top Up
                                                            <?php }?>

                                                            <?php if(in_array("Subscribed", explode(" ", $activity->message))) {?>
                                                                Subscription
                                                            <?php }?>

                                                            <?php if(in_array("UnSubscribed", explode(" ", $activity->message))) {?>
                                                                UnSubscribed
                                                            <?php }?>
                                                        </td>
                                                        <td>
                                                            <?php echo $activity->message ;?>
                                                        </td>
                                                        <td>
                                                            <?php echo date_format(date_create($activity->date), 'jS F, Y'). " at ". date_format(date_create($activity->date), 'H:i:s')?>
                                                        </td>
                                                    </tr>
                                                <?php }?>
                                                </tbody>
                                                <tfoot>
                                                <tr>
                                                    <th>Type</th>
                                                    <th>Activity</th>
                                                    <th>Date Done</th>
                                                </tr>
                                                </tfoot>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="tab-pane " id="password" role="tabpanel">
                                <br>
                                <h4>
                                    Member Donations History
                                </h4>
                                <hr>
                                <div class="table-responsive">
                                    <table id="myTable" class="table table-bordered table-striped">
                                        <thead>
                                        <tr>
                                            <th> Amount Donated</th>
                                            <th> Date Donated</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <?php foreach ($donations as $donation) {?>

                                            <tr>
                                                <td>
                                                    <?php echo "Kshs. ".number_format($donation->amount) ;?>
                                                </td>
                                                <td>
                                                    <?php echo date_format(date_create($donation->date), 'jS F Y') ;?>
                                                </td>
                                            </tr>
                                        <?php }?>
                                        </tbody>
                                        <tfoot>
                                        <tr>
                                            <th> Amount Donated</th>
                                            <th> Date Donated</th>
                                        </tr>
                                        </tfoot>
                                    </table>
                                </div>
                            </div>

                            <div class="tab-pane " id="renewal" role="tabpanel">
                                <br>
                                <h4>
                                    Membership Renewal History
                                </h4>
                                <hr>
                                <div class="col-md-12">
                                    <div>
                                        <div class="table-responsive m-t-10">
                                            <table id="myTable3" class="table table-bordered table-striped">
                                                <thead>
                                                <tr>
                                                    <th>Activity</th>
                                                    <th>Date Done</th>
                                                </tr>
                                                </thead>
                                                <tbody>
                                                <?php foreach ($activities as $activity) {?>
                                                    <?php if(in_array("Renewed", explode(" ", $activity->message))) {?>
                                                        <tr>
                                                            <td>
                                                                <?php echo $activity->message ;?>
                                                            </td>
                                                            <td>
                                                                <?php echo date_format(date_create($activity->date), 'jS F, Y'). " at ". date_format(date_create($activity->date), 'H:i:s')?>
                                                            </td>
                                                        </tr>
                                                    <?php }?>
                                                <?php }?>
                                                </tbody>
                                                <tfoot>
                                                <tr>
                                                    <th>Activity</th>
                                                    <th>Date Done</th>
                                                </tr>
                                                </tfoot>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
