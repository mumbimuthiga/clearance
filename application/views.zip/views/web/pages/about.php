<main class="mdl-layout__content" style="flex: 1 0 auto; background-color: ;">

    <div class="page-content body-content">
        <div class="container" style="margin-bottom: 20px;">
            <br>
            <div class="row">
                <div class="col-sm-6">
                    <div class="card">
                        <div class="card-body">
                            <h5>
                                <b>
                                    Why ODM
                                </b>
                            </h5>
                            <hr>
                            <h6>
                                Citizens Democracy requires responsible citizens who can make sound decisions about
                                their
                                future, and can act on these decisions. ODM supporters have shown through the years that
                                they are ready to make sound and critical decisions that have propelled our country
                                forward.
                            </h6>
                        </div>
                    </div>
                </div>
                <div class="col-sm-6">
                    <div class="card">
                        <div class="card-body">
                            <h5>
                                <b>
                                    Communities
                                </b>
                            </h5>
                            <hr>
                            <h6>
                                Democracy requires a community, or a society of citizens, that can work together. In
                                ODM, we have proven that though separated by language, culture and geography,
                                communities in Kenya can come together and work together to overcome the worst
                                dictatorships. By community we don’t mean the colonial construct known as “tribes” but
                                people, regardless of ethnic extractions, who identify with the national challenges of
                                the day and join in others to agitate for solutions.
                            </h6>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-6">
                    <div class="card">
                        <div class="card-body">
                            <h5>
                                <b>
                                    Institutions
                                </b>
                            </h5>
                            <hr>
                            <h6>
                                Democracy requires institutions with public legitimacy that contribute to strengthening
                                society. But while this is so, ODM has been mindful to not substitute public knowledge
                                for expert knowledge, whose final result always weakens self-determination. ODM believes
                                the people are sovereign not just on paper but by deeds; that’s why our legacy is that
                                of a people driven constitutional dispensation. In ODM, we’ve continually called for
                                strengthening of the following institutions:
                            </h6>
                        </div>
                    </div>
                </div>
                <div class="col-sm-6">
                    <div class="card">
                        <div class="card-body">
                            <h5>
                                <b>
                                    National Assembly and Senate
                                </b>
                            </h5>
                            <hr>
                            <h6>
                                Must be autonomous to check and prevent dictatorial tendencies, abuse of power, looting
                                of the treasury, excesses of the executive or the presidency. Stronger national and
                                county assemblies make stronger laws which protect and empower the weakest of the
                                society.
                            </h6>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-6">
                    <div class="card">
                        <div class="card-body">
                            <h5>
                                <b>
                                    The Media
                                </b>
                            </h5>
                            <hr>
                            <h6>
                                Must be independent; informing, educating, fact-checking and exposing wrongdoing without
                                any bias.
                            </h6>
                        </div>
                    </div>
                </div>
                <div class="col-sm-6">
                    <div class="card">
                        <div class="card-body">
                            <h5>
                                <b>
                                    IEBC
                                </b>
                            </h5>
                            <hr>
                            <h6>
                                The electoral commission must be independent to give whatever government formed public
                                legitimacy by ensuring free, fair, credible and verifiable elections whose results truly
                                reflect the desire and will of the people.
                            </h6>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-6">
                    <div class="card">
                        <div class="card-body">
                            <h5>
                                <b>
                                    The Judiciary
                                </b>
                            </h5>
                            <hr>
                            <h6>
                                Must be independent to uphold and enforce the rule of law and constitutionalism.
                            </h6>
                        </div>
                    </div>
                </div>
                <div class="col-sm-6">
                    <div class="card">
                        <div class="card-body">
                            <h5>
                                <b>
                                    The Central Bank
                                </b>
                            </h5>
                            <hr>
                            <h6>
                                Must be independent of the executive and the presidency to ensure no printing of money
                                for personal political expediency like happened in the run up to 1992 elections.
                            </h6>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-6">
                    <div class="card">
                        <div class="card-body">
                            <h5>
                                <b>
                                    The Civil Service
                                </b>
                            </h5>
                            <hr>
                            <h6>
                                Must be neutral and apolitical to ensure delivery of social services to every citizen
                                without bias or favouritism.
                            </h6>
                        </div>
                    </div>
                </div>
                <div class="col-sm-6">
                    <div class="card">
                        <div class="card-body">
                            <h5>
                                <b>
                                    Security Forces
                                </b>
                            </h5>
                            <hr>
                            <h6>
                                Both the police and the Defence Forces must always be neutral to the political
                                undercurrents of the country. The security forces must always provide security and
                                protect citizens regardless of political affiliation, ethnicity, religion or ideology.
                            </h6>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>
