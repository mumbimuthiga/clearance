<style type="text/css">
    #home_banner {
        background: url('<?php echo base_url("landing.jpg")?>');
        background-repeat: no-repeat;
        background-size: cover;
        background-position: center;
        color: #ffffff;
        height: 90vh;
        left: 0;
        right: 0;
    }

    #inner_banner {
        height: 90vh;
        width: 100%;
        background: rgba(20, 20, 20, 0.7);
        display: -webkit-flex;

    }

</style>


<div id="home_banner">
    <div id="inner_banner">
        <div class="container">
            <div class="row">
                <div class="col-md-12" style="color: white;">
                    <div style="margin-top: 40vh;" class="hidden-xs"></div>
                    <div style="margin-top: 10vh;" class="hidden-lg hidden-md hidden-sm"></div>
                    <div class="hidden-xs">
                        <h2 style="text-align: center; font-size: 40px !important; font-family: Ubuntu,sans-serif !important;">
                            Membership Management System
                        </h2>
                        <br>
                        <div class="text-center">
                            <a href="<?php echo base_url('auth/signup')?>" target="_blank" class="btn btn-lg" style="background: transparent; color: #ff924c; border: solid 1px #ff924c; border-radius: 0; font-family: Ubuntu,sans-serif">
                                Become a Member
                            </a>
                        </div>
                    </div>
                    <div class="hidden-lg hidden-md hidden-sm">
                        <h2 class="h2" style="font-family: Ubuntu,sans-serif !important;">
                            Membership Management System
                        </h2>
                        <br>
                        <div>
                            <a href="<?php echo base_url('auth/signup')?>" target="_blank" class="btn btn-lg" style="background: transparent; color: #ff924c; border: solid 1px #ff924c; border-radius: 0; font-family: Ubuntu,sans-serif">
                                Become a Member
                            </a>
                        </div>
                    </div>
                    <div style="margin-top: 4vh;" class="hidden-xs"></div>
                    <div style="margin-top: 10vh;" class="hidden-lg hidden-md hidden-sm"></div>
                    <div style="margin-top: 15vh;" class="hidden-xs"></div>
                </div>
            </div>
        </div>
    </div>
</div>