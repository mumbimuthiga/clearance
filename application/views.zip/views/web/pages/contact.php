
<style type="text/css">
    input#form_input
    {
        background: rgb(248, 248, 248); !important;
        height: 50px;
    }

    textarea#form_input
    {
        background: rgb(248, 248, 248); !important;
    }
</style>
<main class="mdl-layout__content" style="flex: 1 0 auto; background-color: #FFFFFF;">

    <div class="page-content body-content">
        <div class="container" style="margin-bottom: 20px;">
            <br>
            <div class="row">
                <div class="col-sm-9">
                    <div class="row">
                        <div class="col-md-12">
                            <div style="justify-content: space-around;">
                                <h4>
                                    Get In Touch
                                </h4>
                                <?php if(isset($_GET['email'])) {?>
                                    <div class="col-md-12">
                                        <br>
                                        <div class="alert alert-success">
                                            <b>
                                                <i class="glyphicon glyphicon-check"></i>
                                                &nbsp;
                                                Success
                                                &nbsp;
                                            </b>
                                            Your message has been sent. Thank you.
                                        </div>
                                    </div>
                                <?php }?>
                                <div class="panel panel-default" style="border-radius: 0">
                                    <div class="panel-body">
                                        <form method="post" action="<?php echo base_url('web/send_message')?>" id="messages_form">
                                            <div class="form-group">
                                                <input type="text" name="name" id="form_input" class="form-control" style="border-radius: 0" placeholder="Your Full Name" required>
                                            </div>
                                            <div class="form-group">
                                                <input type="email" name="email" id="form_input" class="form-control" style="border-radius: 0" placeholder="Your Email Address" required>
                                            </div>
                                            <div class="form-group">
                                                <input type="number" name="phone" id="form_input" class="form-control" style="border-radius: 0" placeholder="Your Phone Number" required>
                                            </div>
                                            <div class="form-group">
                                                <textarea class="form-control" rows="5" name="message" id="form_input" style="border-radius: 0" placeholder="Type your message.." required></textarea>
                                            </div>
                                            <div class="form-group">
                                                <button class="btn" type="submit" style="background: #ff924c; color: white;">
                                                    Send Message
                                                </button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                            <br>
                        </div>
                    </div>
                </div>
                <div class="col-sm-3">
                    <div class="row">
                        <div class="col-md-12">
                            <h4>
                                Contact Details
                            </h4>
                            <div class="panel panel-default" style="background: rgb(248, 248, 248); border-radius: 0">
                                <div class="panel-body">
                                    <div class="row" style="margin-bottom: 20px;">
                                        <div class="col-md-12">
                                            <ul class="list-inline">
                                                <li>
                                                    <i class="fa fa-phone" style="font-size: 19px;"></i>
                                                </li>
                                                <li>
                                                    020-20253481
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="row" style="margin-bottom: 20px;">
                                        <div class="col-md-12">
                                            <ul class="list-inline">
                                                <li>
                                                    <i class="fa fa-envelope" style="font-size: 19px;"></i>
                                                </li>
                                                <li>
                                                    info@odm.co.ke
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="row" style="margin-bottom: 10px;">
                                        <div class="col-md-12">
                                            <ul class="list-inline">
                                                <li>
                                                    <i class="fa fa-globe" style="font-size: 19px;"></i>
                                                </li>
                                                <li>
                                                    <a href="http://www.odm.co.ke" style="color: #ff924c !important;" target="_blank">
                                                        Odm Website
                                                    </a>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="row" style="margin-bottom: 20px;">
                                        <div class="col-md-12">
                                            <h4>
                                                We are Social
                                            </h4>
                                            <ul class="list-inline">
                                                <li style="margin-right: 10px;">
                                                    <a href="#" target="_blank">
                                                        <i class="fa fa-facebook-official" style="font-size: 32px; color: #888; border-radius: 1px"></i>
                                                    </a>
                                                </li>
                                                <li style="margin-right: 10px;">
                                                    <a href="#">
                                                        <i class="fa fa-linkedin" style="font-size: 32px; color: #888; border-radius: 1px"></i>
                                                    </a>
                                                </li>
                                                <li style="margin-right: 10px;">
                                                    <a href="#" target="_blank">
                                                        <i class="fa fa-twitter-square" style="font-size: 32px; color: #888; border-radius: 1px"></i>
                                                    </a>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>