<style type="text/css">
    a{
        color: white;
        text-decoration: none !important;
    }
</style>
<footer class="mdl-mega-footer  mdl-color-text--black"
        style="flex: 0 0 auto; background-color: #ff924c; border-radius: 0;">
    <br>
    <div class="container">
        <div class="row">
            <div class="col-md-5">
                <h5 style="color: white; font-family: Ubuntu,sans-serif">
                    <b>
                        About ODM
                    </b>
                </h5>
                <p style="color: white; font-size: 16px; font-family: Ubuntu,sans-serif">
                    Democracy requires a community, or a society of citizens, that can work together. In ODM, we have
                    proven that though separated by language, culture and geography, communities in Kenya can come
                    together and work together to overcome the worst dictatorships.
                </p>
            </div>
            <div class="col-md-3">
                <div>
                    <h5 style="color: white; font-family: Ubuntu,sans-serif">
                        <b>
                            Quick Links
                        </b>
                    </h5>
                    <ul class="list-unstyled" style="color: white; font-family: Ubuntu,sans-serif">
                        <li>
                            <a href="<?php echo base_url('web') ?>" style="font-size: 16px;">
                                <i class="fa fa-home"></i>
                                &nbsp;
                                Home
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo base_url('auth/signup') ?>"
                               style="font-size: 16px;">
                                <i class="fa fa-user"></i>
                                &nbsp;
                                Join ODM
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo base_url('auth/Login') ?>"
                               style="font-size: 16px;">
                                <i class="fa fa-lock"></i>
                                &nbsp;
                                Login
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo base_url('auth/verify')?>" style="font-size: 16px;">
                                <i class="fa fa-check-circle"></i>
                                &nbsp;
                                Verify Membership
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="col-md-4">
                <h5 style="color: white; font-family: Ubuntu,sans-serif">
                    <b>
                        Contact Information
                    </b>
                </h5>
                <ul class="list-unstyled" style="color: white; font-family: Ubuntu,sans-serif">
                    <li style="font-size: 16px;">
                        <i class="fa fa-map-marker"></i>
                        &nbsp;
                        Orange House, Menelik Road, Nairobi
                    </li>
                    <li style="font-size: 16px;">
                        <i class="fa fa-phone"></i>
                        &nbsp;
                         020-20253481
                    </li>
                    <li style="font-size: 16px;">
                        <i class="fa fa-envelope"></i>
                        &nbsp;
                        info@odm.co.ke
                    </li>
                    <li style="font-size: 16px;">
                        <i class="fa fa-link"></i>
                        &nbsp;
                        <a href="http://www.odm.co.ke" target="_blank" style="">
                            ODM Website
                        </a>
                    </li>
                </ul>
            </div>
        </div>
        <div class="row">
            <br><br>
            <div class="text-center">
                <hr>
                <br>
                <p style="color: white; font-size: 16px; font-family: Ubuntu,sans-serif">
                    copyright&nbsp;&copy;&nbsp;ODM Member Management System&nbsp;2018
                </p>
            </div>
        </div>
    </div>
</footer>
