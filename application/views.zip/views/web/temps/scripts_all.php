</div>
</body>

<script src="<?php echo base_url() ?>assets/node_modules/jquery/jquery.min.js"></script>
<script src="<?php echo base_url() ?>assets/node_modules/bootstrap/js/popper.min.js"></script>
<script src="<?php echo base_url() ?>assets/node_modules/bootstrap/js/bootstrap.min.js"></script>
<script src="<?php echo base_url() ?>assets/node_modules/sweetalert/sweetalert.min.js"></script>
<script src="<?php echo base_url('assets/material/js/material.min.js') ?>" type="text/javascript"></script>

<script src="<?php echo base_url('assets/select/select2.min.js') ?>"></script>
<script src="<?php echo base_url('assets/external/custom.js') ?>" type="text/javascript"></script>



</html>