<?php

$url_active = $this->uri->segment(2);

?>


<div class="mdl-layout__drawer mdl-layout--small-screen-only">
    <span class="mdl-layout-title">
        <a href="<?php echo base_url('web/') ?>" style="height: 40px;">
                    <img src="<?php echo base_url('logo3.png')?>" class="img-responsive">
               </a>
    </span>
    <nav class="mdl-navigation">
        <a class="mdl-navigation__link mdl-color-text--black"
           href="<?php echo base_url('web/') ?>" target="_blank">
            <i class="fa fa-home"></i>
            &nbsp;
            Home
        </a>
        <a class="mdl-navigation__link mdl-color-text--black"
           href="<?php echo base_url('auth/verify')?>" target="_blank">
            <i class="fa fa-check-circle"></i>
            &nbsp;
            Verify Membership
        </a>
        <a class="mdl-navigation__link mdl-color-text--black"
           href="<?php echo base_url('web/about') ?>" target="_blank">
            <i class="fa fa-address-book-o"></i>
            &nbsp;
            About Us
        </a>
        <a class="mdl-navigation__link mdl-color-text--black"
           href="<?php echo base_url('web/contact') ?>" target="_blank">
            <i class="fa fa-address-envelope"></i>
            &nbsp;
            Contact Us
        </a>
    </nav>
</div>