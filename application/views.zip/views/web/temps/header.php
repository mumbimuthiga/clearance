
<?php

    $url_active = $this->uri->segment(2);

?>


<header class="mdl-layout__header mdl-color--white">

    <div class="container">
        <div class="row">
            <div class="mdl-layout__header-row mdl-color--white" style="height: 80px; padding-left: 0; padding-right: 0">
                <div class="col-md-2 hidden-sm">
                    <div  style="margin-left: 0; height: 80px;">
                        <a class="mdl-color-text--black hidden-xs" href="<?php echo base_url('web/') ?>">
                            <img src="<?php echo base_url('logo3.png')?>" class="img-responsive" style="height: 100%;">
                        </a>
                    </div>
                </div>

                <div class="col-md-7 hidden-xs">
                    <ul class="list-inline" style="margin-top: 15px;">
                        <li style="margin-right: 15px;">
                            <a href="<?php echo base_url('web/')?>" style="color: <?php echo ($url_active == '' ? '#ff924c' : 'black')?>; font-size: 16px; font-family: Ubuntu,sans-serif">
                                <i class="fa fa-home"></i>
                                &nbsp;
                                HOME
                            </a>
                        </li>
                        <li style="margin-right: 15px;">
                            <a href="<?php echo base_url('auth/verify')?>" target="_blank" style="color: <?php echo ($url_active == 'organizations' ? '#ff924c' : 'black')?>; font-size: 16px; font-family: Ubuntu,sans-serif">
                                <i class="fa fa-check-circle"></i>
                                &nbsp;
                                VERIFY MEMBERSHIP
                            </a>
                        </li>
                        <li style="margin-right: 15px;">
                            <a href="<?php echo base_url('web/about')?>" style="color: <?php echo ($url_active == 'about' ? '#ff924c' : 'black')?>; font-size: 16px; font-family: Ubuntu,sans-serif">
                                <i class="fa fa-book"></i>
                                &nbsp;
                                ABOUT US
                            </a>
                        </li>
                        <li style="margin-right: 15px;">
                            <a href="<?php echo base_url('web/contact')?>" style="color: <?php echo ($url_active == 'contact' ? '#ff924c' : 'black')?>; font-size: 16px; font-family: Ubuntu,sans-serif">
                                <i class="fa fa-connectdevelop"></i>
                                &nbsp;
                                CONTACT US
                            </a>
                        </li>
                    </ul>
                </div>

                <div class="col-md-3">
                    <br>
                    <ul class="list-inline pull-right">
                        <li style="border-right: solid 1px black; margin-top: 8px;">
                            <a  href="<?php echo base_url('auth/login')?>" target="_blank" style="border-radius: 0; margin-right: 10px;  color: #ff924c; font-size: 15px !important; font-family: Ubuntu,sans-serif">
                                LOGIN
                            </a>
                        </li>
                        <li class="pull-right">
                            <a class="btn btn-md" href="<?php echo base_url('auth/signup')?>" target="_blank" id="demo-menu-lower-left" style="border-radius: 0; margin-left: 10px; background: #ff924c; color: white; font-size: 15px !important; padding: 10px 16px !important; font-family: Ubuntu,sans-serif">
                                JOIN
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>

</header>

