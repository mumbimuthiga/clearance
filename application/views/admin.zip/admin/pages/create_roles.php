<div class="container-fluid">
    <?php $this->load->view('admin/pages/head_info') ;?>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-12">
                            <form id="role_form" action="<?php echo base_url('admin/new_role')?>"
                                  method="post">
                                <div id="roleForm" class="modal fade" tabindex="-1" role="dialog"
                                     aria-labelledby="myModalLabel" aria-hidden="true"
                                     style="display: none;">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h4 class="modal-title">Create Role</h4>
                                                <button type="button" class="close" data-dismiss="modal"
                                                        aria-hidden="true">×
                                                </button>
                                            </div>
                                            <div class="modal-body">
                                                <div class="form-group">
                                                    <label for="name">
                                                        Role Name
                                                    </label>
                                                    <input type="text" class="form-control" name="name"
                                                           id="name" required
                                                           placeholder="Enter Role">
                                                </div>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button"
                                                        class="btn btn-default waves-effect btn-sm"
                                                        data-dismiss="modal">Close
                                                </button>

                                                <button type="submit"
                                                        class="btn btn-success waves-effect waves-light btn-sm">
                                                    Create
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                        <div class="col-sm-10">
                            <h5>
                                Create User Roles
                            </h5>
                        </div>
                        <div class="col-sm-2">
                            <button class="btn btn-inverse" data-toggle="modal" data-target="#roleForm">
                                Create Role
                            </button>
                        </div>
                    </div>
                    <hr>
                    <div class="table-responsive">
                        <table id="myTable" class="table table-bordered table-striped">
                            <thead>
                            <tr>
                                <th>Role</th>
                                <th>Created By</th>
                                <th>Date Created</th>
                                <th>Action</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php foreach ($roles as $role) {?>
                                <?php

                                $m_details = $this->Admin_model->get_admin_details($role->created_by);
                                ?>

                                <tr>
                                    <td>
                                        <?php echo $role->name ;?>
                                    </td>
                                    <td>
                                        <?php echo ucwords(strtolower($m_details->fname." ".$m_details->lname), " ")?>
                                    </td>
                                    <td>
                                        <?php echo date_format(date_create($role->date), 'jS F Y') ;?>
                                    </td>
                                    <td>
                                        <button class="btn btn-success btn-sm" onclick="delete_role('<?php echo $role->id?>')">
                                            Delete Role
                                        </button>
                                    </td>
                                </tr>
                            <?php }?>
                            </tbody>
                            <tfoot>
                            <tr>
                                <th>Role</th>
                                <th>Created By</th>
                                <th>Date Created</th>
                                <th>Action</th>
                            </tr>
                            </tfoot>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
