<div class="container-fluid">
    <?php $this->load->view('admin/pages/head_info') ;?>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body p-b-0">
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="card">
                                <div class="card-body">
                                    <form id="sms_form" method="post" action="<?php echo base_url('admin/send_member_sms')?>">
                                        <div class="row">
                                            <div class="col-12">
                                                <div class="modal fade" id="smsModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                                    <div class="modal-dialog" role="document">
                                                        <div class="modal-content">
                                                            <div class="modal-header">
                                                                <h5 class="modal-title" id="exampleModalLabel">Compose SMS</h5>
                                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                    <span aria-hidden="true">&times;</span>
                                                                </button>
                                                            </div>
                                                            <div class="modal-body">
                                                                <div class="form-group">
                                                                    <label for="sms_body">
                                                                        Message
                                                                    </label>
                                                                    <textarea class="form-control" name="message" id="sms_body" rows="6" required></textarea>
                                                                </div>
                                                            </div>
                                                            <div class="modal-footer">
                                                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                                                <button type="submit" class="btn btn-inverse">Send SMS</button>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-sm-10">
                                                <h5>
                                                    ODM SMS Alerts Sent
                                                </h5>
                                            </div>
                                            <div class="col-sm-2">
                                                <button class="btn btn-inverse btn-sm" type="button" data-toggle="modal" data-target="#smsModal">
                                                    Send SMS
                                                </button>
                                            </div>
                                        </div>
                                        <hr>
                                        <div class="table-responsive">
                                            <table id="myTable" class="table table-bordered table-striped">
                                                <thead>
                                                <tr>
                                                    <th> Message </th>
                                                    <th> Date Sent</th>
                                                </tr>
                                                </thead>
                                                <tbody>
                                                <?php foreach ($sms as $sm) {?>
                                                    <tr>
                                                        <td>
                                                            <?php echo $sm->sms?>
                                                        </td>
                                                        <td>
                                                            <?php echo date_format(date_create($sm->date), 'jS F, Y')?>
                                                        </td>
                                                    </tr>
                                                <?php }?>
                                                </tbody>
                                                <tfoot>
                                                <tr>
                                                    <th> Message </th>
                                                    <th> Date Sent</th>
                                                </tr>
                                                </tfoot>
                                            </table>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php /*$this->load->view('user/pages/social_links')*/?>
    </div>
</div>
