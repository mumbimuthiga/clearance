<div class="container-fluid">
    <?php $this->load->view('admin/pages/head_info') ;?>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card">
                    <div class="card-body p-b-0">
                        <!-- Nav tabs -->
                        <ul class="nav nav-tabs customtab" role="tablist">
                            <li class="nav-item"> <a class="nav-link active" data-toggle="tab" href="#info" role="tab"><span class="hidden-sm-up"><i class="ti-info"></i></span> <span class="hidden-xs-down">Email Subscribers</span></a> </li>
                            <li class="nav-item"> <a class="nav-link" data-toggle="tab" href="#update" role="tab"><span class="hidden-sm-up"><i class="ti-angle-up"></i></span> <span class="hidden-xs-down">SMS Subscribers</span></a> </li>
                        </ul>
                        <div class="tab-content">
                            <div class="tab-pane active" id="info" role="tabpanel">
                                <form id="emails_form" method="post" action="<?php echo base_url('admin/send_alert_emails')?>">
                                    <br>
                                    <div class="row">
                                        <div class="col-12">
                                            <div class="modal fade" id="emailModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                                <div class="modal-dialog" role="document">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h5 class="modal-title" id="exampleModalLabel">Compose Email</h5>
                                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                <span aria-hidden="true">&times;</span>
                                                            </button>
                                                        </div>
                                                        <div class="modal-body">
                                                            <div class="form-group">
                                                                <label for="email_subject">
                                                                    Subject
                                                                </label>
                                                                <input type="text" class="form-control" name="subject" id="email_subject">
                                                            </div>
                                                            <div class="form-group">
                                                                <label for="email_body">
                                                                    Message
                                                                </label>
                                                                <textarea class="form-control" name="message" id="email_body" rows="6"></textarea>
                                                            </div>
                                                        </div>
                                                        <div class="modal-footer">
                                                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                                            <button type="submit" class="btn btn-inverse">Send Email</button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-sm-10">
                                            <h4>
                                                Members Subscribed for Email Alerts
                                            </h4>
                                        </div>
                                        <div class="col-sm-2">
                                            <button type="button" class="btn btn-inverse" data-toggle="modal" data-target="#emailModal">
                                                Send Email Alert
                                            </button>
                                        </div>
                                    </div>
                                    <hr>
                                    <div class="table-responsive">
                                        <table id="myTable" class="table table-bordered table-striped">
                                            <thead>
                                            <tr>
                                                <th>Member</th>
                                                <th> Phone</th>
                                                <th>County</th>
                                                <th>Constituency</th>
                                                <th>Ward</th>
                                                <th>Date Subscribed</th>
                                            </tr>
                                            </thead>
                                            <tbody>
                                            <?php foreach ($email_subscribers as $subscriber) {?>
                                                <?php

                                                $m_details = $this->User_model->get_user_details($subscriber->user_id);
                                                $user_county = $this->User_model->get_county($m_details->county);
                                                $user_constituency = $this->User_model->get_constituency($m_details->constituency);
                                                $user_ward = $this->User_model->get_ward($m_details->ward);
                                                ?>

                                                <tr>
                                                    <td>
                                                        <input type="hidden" name="user_id[]" value="<?php echo $subscriber->user_id ;?>">
                                                        <?php echo ucwords(strtolower($m_details->fname." ".$m_details->other_names), " ")?>
                                                    </td>
                                                    <td>
                                                        <?php echo $m_details->phone ;?>
                                                    </td>
                                                    <td>
                                                        <?php echo ucfirst(strtolower($user_county))?>
                                                    </td>
                                                    <td>
                                                        <?php echo ucfirst(strtolower($user_constituency))?>
                                                    </td>
                                                    <td>
                                                        <?php echo ucfirst(strtolower($user_ward))?>
                                                    </td>
                                                    <td>
                                                        <?php echo date_format(date_create($subscriber->date), 'jS F Y') ;?>
                                                    </td>
                                                </tr>
                                            <?php }?>
                                            </tbody>
                                            <tfoot>
                                            <tr>
                                                <th>Member</th>
                                                <th> Phone</th>
                                                <th>County</th>
                                                <th>Constituency</th>
                                                <th>Ward</th>
                                                <th>Date Subscribed</th>
                                            </tr>
                                            </tfoot>
                                        </table>
                                    </div>
                                </form>
                            </div>
                            <div class="tab-pane " id="update" role="tabpanel">
                                <form id="sms_form" method="post" action="<?php echo base_url('admin/send_alert_sms')?>">
                                    <br>
                                    <div class="row">
                                        <div class="col-12">
                                            <div class="modal fade" id="smsModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                                <div class="modal-dialog" role="document">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h5 class="modal-title" id="exampleModalLabel">Compose SMS</h5>
                                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                <span aria-hidden="true">&times;</span>
                                                            </button>
                                                        </div>
                                                        <div class="modal-body">
                                                            <div class="form-group">
                                                                <label for="email_body">
                                                                    Message
                                                                </label>
                                                                <textarea class="form-control" name="message" id="sms_body" rows="6"></textarea>
                                                            </div>
                                                        </div>
                                                        <div class="modal-footer">
                                                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                                            <button type="submit" class="btn btn-inverse">Send SMS</button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-sm-10">
                                            <h4>
                                                Members Subscribed for SMS Alerts
                                            </h4>
                                        </div>
                                        <div class="col-sm-2">
                                            <button type="button" class="btn btn-inverse" data-toggle="modal" data-target="#smsModal">
                                                Send SMS Alert
                                            </button>
                                        </div>
                                    </div>
                                    <hr>
                                    <div class="table-responsive">
                                        <table id="myTable2" class="table table-bordered table-striped">
                                            <thead>
                                            <tr>
                                                <th>Member</th>
                                                <th> Phone</th>
                                                <th>County</th>
                                                <th>Constituency</th>
                                                <th>Ward</th>
                                                <th>Date Subscribed</th>
                                            </tr>
                                            </thead>
                                            <tbody>
                                            <?php foreach ($sms_subscribers as $subscriber) {?>
                                                <?php

                                                $m_details = $this->User_model->get_user_details($subscriber->user_id);
                                                $user_county = $this->User_model->get_county($m_details->county);
                                                $user_constituency = $this->User_model->get_constituency($m_details->constituency);
                                                $user_ward = $this->User_model->get_ward($m_details->ward);
                                                ?>

                                                <tr>
                                                    <td>
                                                        <input type="hidden" name="user_id[]" value="<?php echo $subscriber->user_id ;?>">
                                                        <?php echo ucwords(strtolower($m_details->fname." ".$m_details->other_names), " ")?>
                                                    </td>
                                                    <td>
                                                        <?php echo $m_details->phone ;?>
                                                    </td>
                                                    <td>
                                                        <?php echo ucfirst(strtolower($user_county))?>
                                                    </td>
                                                    <td>
                                                        <?php echo ucfirst(strtolower($user_constituency))?>
                                                    </td>
                                                    <td>
                                                        <?php echo ucfirst(strtolower($user_ward))?>
                                                    </td>
                                                    <td>
                                                        <?php echo date_format(date_create($subscriber->date), 'jS F Y') ;?>
                                                    </td>
                                                </tr>
                                            <?php }?>
                                            </tbody>
                                            <tfoot>
                                            <tr>
                                                <th>Member</th>
                                                <th> Phone</th>
                                                <th>County</th>
                                                <th>Constituency</th>
                                                <th>Ward</th>
                                                <th>Date Subscribed</th>
                                            </tr>
                                            </tfoot>
                                        </table>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
