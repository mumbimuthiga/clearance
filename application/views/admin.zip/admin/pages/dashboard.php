<style>
    #chartdiv {
        width		: 100%;
        height		: 360px;
        font-size	: 11px;
    }

    #chartdiv_fee {
        width		: 100%;
        height		: 360px;
        font-size	: 11px;
    }
</style>


<div class="container-fluid">
    <?php $this->load->view('admin/pages/head_info') ;?>
    <div class="row">
        <div class="col-lg-3 col-md-3">
            <div class="card">
                <a href="<?php echo base_url('admin/create_roles')?>">
                    <div class="card-body">
                        <div class="d-flex p-10 no-block">
                            <div class="align-slef-center">
                                <h2 class="number">
                                    <?php echo number_format(count($roles)) ;?>
                                </h2>
                                <h5 class="text-muted m-b-0">
                                    All Roles
                                </h5>
                            </div>
                            <div class="align-self-center display-6 ml-auto"><i class="text-success icon-user"></i>
                            </div>
                        </div>
                    </div>
                    <div class="progress">
                        <div class="progress-bar bg-success" role="progressbar" aria-valuenow="100" aria-valuemin="0"
                             aria-valuemax="100" style="width:100%; height:3px;"><span
                                class="sr-only"></span></div>
                    </div>
                </a>
            </div>
        </div>
        <div class="col-lg-3 col-md-3">
            <div class="card">
                <a href="<?php echo base_url('admin/members')?>">
                    <div class="card-body">
                        <div class="d-flex p-10 no-block">
                            <div class="align-slef-center">
                                <h2 class="number">
                                    <?php echo number_format(count($members_active)) ;?>
                                </h2>
                                <h5 class="text-muted m-b-0">
                                   Active Members
                                </h5>
                            </div>
                            <div class="align-self-center display-6 ml-auto"><i
                                    class="text-primary icon-Love-User"></i></div>
                        </div>
                    </div>
                    <div class="progress">
                        <div class="progress-bar bg-primary" role="progressbar" aria-valuenow="100" aria-valuemin="0"
                             aria-valuemax="100" style="width:100%; height:3px;"><span
                                class="sr-only"></span></div>
                    </div>
                </a>
            </div>
        </div>
        <div class="col-lg-3 col-md-3">
            <div class="card">
                <a href="<?php echo base_url('admin/members_terminated')?>">
                    <div class="card-body">
                        <div class="d-flex p-10 no-block">
                            <div class="align-slef-center">
                                <h2 class="number">
                                    <?php echo number_format(count($members_terminated)) ;?>
                                </h2>
                                <h5 class="text-muted m-b-0">
                                    Terminated Members
                                </h5>
                            </div>
                            <div class="align-self-center display-6 ml-auto"><i class="text-danger icon-Lock-User"></i>
                            </div>
                        </div>
                    </div>
                    <div class="progress">
                        <div class="progress-bar bg-success" role="progressbar" aria-valuenow="100" aria-valuemin="0"
                             aria-valuemax="100" style="width:100%; height:3px;"><span
                                class="sr-only"></span></div>
                    </div>
                </a>
            </div>
        </div>
        <div class="col-lg-3 col-md-3">
            <div class="card">
                <a href="<?php echo base_url('admin/donations')?>">
                    <div class="card-body">
                        <div class="d-flex p-10 no-block">
                            <div class="align-slef-center">
                                <h2 class="number">
                                    Ksh. <?php echo number_format($total_donations) ;?>
                                </h2>
                                <h5 class="text-muted m-b-0">
                                    Donations
                                </h5>
                            </div>
                            <div class="align-self-center display-6 ml-auto"><i class="text-primary icon-Money"></i>
                            </div>
                        </div>
                    </div>
                    <div class="progress">
                        <div class="progress-bar bg-primary" role="progressbar" aria-valuenow="100" aria-valuemin="0"
                             aria-valuemax="100" style="width:100%; height:3px;"><span
                                class="sr-only"></span></div>
                    </div>
                </a>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-md-6">
            <div class="card">
                <div class="card-body">
                    <h5>
                        Donations in <?php echo date('Y') ;?>
                    </h5>
                    <hr>
                    <div id="chartdiv"></div>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="card">
                <div class="card-body">
                    <h5>
                        Registration Fees in <?php echo date('Y') ;?>
                    </h5>
                    <hr>
                    <div id="chartdiv_fee"></div>
                </div>
            </div>
        </div>
        <?php /*$this->load->view('user/pages/social_links')*/?>
    </div>
</div>

