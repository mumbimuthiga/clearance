<div class="container-fluid">
    <?php $this->load->view('admin/pages/head_info') ;?>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-12">
                        </div>
                        <div class="col-sm-10">
                            <h5>
                                ODM Donations History
                            </h5>
                        </div>
                        <div class="col-sm-2">

                        </div>
                    </div>
                    <hr>
                    <div class="table-responsive">
                        <table id="myTable" class="table table-bordered table-striped">
                            <thead>
                            <tr>
                                <th>Member</th>
                                <th>Phone</th>
                                <th>County</th>
                                <th>Constituency</th>
                                <th>Ward</th>
                                <th> Total Donated</th>
                                <th> Last Donation Date</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php foreach ($donations as $donation) {?>
                                <?php

                                    $m_details = $this->User_model->get_user_details($donation->user_id);
                                    $user_county = $this->User_model->get_county($m_details->county);
                                    $user_constituency = $this->User_model->get_constituency($m_details->constituency);
                                    $user_ward = $this->User_model->get_ward($m_details->ward);
                                    $total_donations = $this->User_model->get_total_user_donations($donation->user_id);
                                ?>

                                <tr>
                                    <td>
                                        <?php echo ucwords(strtolower($m_details->fname." ".$m_details->other_names), " ")?>
                                    </td>
                                    <td>
                                        <?php echo $m_details->phone ;?>
                                    </td>
                                    <td>
                                        <?php echo ucfirst(strtolower($user_county))?>
                                    </td>
                                    <td>
                                        <?php echo ucfirst(strtolower($user_constituency))?>
                                    </td>
                                    <td>
                                        <?php echo ucfirst(strtolower($user_ward))?>
                                    </td>
                                    <th>
                                        <?php echo "Kshs. ".number_format($total_donations) ;?>
                                    </th>
                                    <td>
                                        <?php echo date_format(date_create($donation->date), 'jS F Y') ;?>
                                    </td>
                                </tr>
                            <?php }?>
                            </tbody>
                            <tfoot>
                            <tr>
                                <th>Member</th>
                                <th>Phone</th>
                                <th>County</th>
                                <th>Constituency</th>
                                <th>Ward</th>
                                <th> Total Donated</th>
                                <th>Last Donation Date</th>
                            </tr>
                            </tfoot>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
