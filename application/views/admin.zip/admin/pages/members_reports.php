<style>
    #chartdiv_gender {
        width		: 100%;
        height		: 360px;
        font-size	: 11px;
    }

    #chartdiv_members_growth {
        width		: 100%;
        height		: 360px;
        font-size	: 11px;
    }
</style>


<div class="container-fluid">
    <?php $this->load->view('admin/pages/head_info') ;?>
    <div class="row">
        <div class="col-md-6">
            <div class="card">
                <div class="card-body">
                    <h5>
                        Gender Distribution
                    </h5>
                    <hr>
                    <div id="chartdiv_gender"></div>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="card">
                <div class="card-body">
                    <h5>
                        ODM Members Growth in <?php echo date('Y') ;?>
                    </h5>
                    <hr>
                    <div id="chartdiv_members_growth"></div>
                </div>
            </div>
        </div>
        <?php /*$this->load->view('user/pages/social_links')*/?>
    </div>
</div>

