<div class="container-fluid">
    <?php $this->load->view('admin/pages/head_info') ;?>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-12">
                        </div>
                        <div class="col-sm-10">
                            <h5>
                                ODM Terminated Members
                            </h5>
                        </div>
                        <div class="col-sm-2">

                        </div>
                    </div>
                    <hr>
                    <div class="table-responsive">
                        <table id="myTable" class="table table-bordered table-striped">
                            <thead>
                            <tr>
                                <th>Member</th>
                                <th>Phone</th>
                                <th>County</th>
                                <th>Constituency</th>
                                <th>Ward</th>
                                <th>Action</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php foreach ($members_terminated as $value) {?>
                                <?php

                                $user_county = $this->User_model->get_county($value->county);
                                $user_constituency = $this->User_model->get_constituency($value->constituency);
                                $user_ward = $this->User_model->get_ward($value->ward);
                                ?>

                                <tr>
                                    <th>
                                        <?php echo ucwords(strtolower($value->fname." ".$value->other_names), " ")?>
                                    </th>
                                    <th>
                                        <?php echo $value->phone ;?>
                                    </th>
                                    <td>
                                        <?php echo ucfirst(strtolower($user_county))?>
                                    </td>
                                    <td>
                                        <?php echo ucfirst(strtolower($user_constituency))?>
                                    </td>
                                    <td>
                                        <?php echo ucfirst(strtolower($user_ward))?>
                                    </td>
                                    <td>
                                        <button class="btn btn-outline-success btn-sm" onclick="activate_user('<?php echo $value->user_id?>')">
                                            Activate Member
                                        </button>
                                    </td>
                                </tr>
                            <?php }?>
                            </tbody>
                            <tfoot>
                            <tr>
                                <th>Member</th>
                                <th>Phone</th>
                                <th>County</th>
                                <th>Constituency</th>
                                <th>Ward</th>
                                <th>Action</th>
                            </tr>
                            </tfoot>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
