<div class="container-fluid">
    <?php $this->load->view('admin/pages/head_info') ;?>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body p-b-0">
                    <div class="row">
                        <div class="col-sm-3" id="support_issues_border">
                            <br>
                            <h5>
                                Filter Search
                            </h5>
                            <hr>
                            <form method="post" action="<?php echo base_url('admin/search_user/roles')?>">
                                <div class="form-group">
                                    <label for="interest_groups">
                                        Interest Groups
                                    </label>
                                    <select class="select2 m-b-10 select2-multiple" style="width: 100%" multiple="multiple" data-placeholder="Choose" name="interest_groups[]" id="interest_groups">
                                        <option value="">--- Add Group ---</option>
                                        <?php foreach ($groups as $group) {?>
                                            <option value="<?php echo $group->id?>" <?php echo (in_array($group->id, $group_s) ? 'selected' : '')?> >
                                                <?php echo ucwords(strtolower($group->name), " ")?>
                                            </option>
                                        <?php }?>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="gender">
                                        Gender
                                    </label>
                                    <select id="gender" class="form-control select2" name="gender">
                                        <option value="">All</option>
                                        <?php foreach ($gender as $value) {?>
                                            <option value="<?php echo $value->id?>" <?php echo ($value->id == $sex ? 'selected' : '')?>>
                                                <?php echo $value->gender ;?>
                                            </option>
                                        <?php }?>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="county">
                                        County
                                    </label>
                                    <select class="form-control select2" name="county" id="county" onchange="get_constituencies()">
                                        <option value="">--- Add County ---</option>
                                        <?php foreach ($counties as $county) {?>
                                            <option value="<?php echo $county->id?>" <?php echo ($county->id == $county_s ? 'selected' : '')?> >
                                                <?php echo ucwords(strtolower($county->name), " ")?>
                                            </option>
                                        <?php }?>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="constituency">
                                        Constituency
                                    </label>
                                    <select class="form-control select2" name="constituency" id="constituency" onchange="get_wards()">
                                        <option value="">--- Add Constituency ---</option>
                                        <?php foreach ($all_const as $value) {?>
                                            <option value="<?php echo $value->id?>" <?php echo ($value->id == $constituency_s ? 'selected' : '')?> >
                                                <?php echo ucwords(strtolower($value->name), " ")?>
                                            </option>
                                        <?php }?>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="wards">
                                        Ward
                                    </label>
                                    <select class="form-control select2" name="ward" id="wards">
                                        <option value="">--- Add Ward ---</option>
                                        <?php foreach ($all_wards as $value) {?>
                                            <option value="<?php echo $value->id?>" <?php echo ($value->id == $ward_s ? 'selected' : '')?> >
                                                <?php echo ucwords(strtolower($value->name), " ")?>
                                            </option>
                                        <?php }?>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <button class="btn btn-inverse" id="btn-bg" style="width: 100%">
                                        <i class="fa fa-search"></i>
                                        &nbsp;
                                        Search
                                    </button>
                                </div>
                            </form>
                        </div>
                        <div class="col-sm-9" id="support_issues_border">
                            <div class="card">
                                <div class="card-body">
                                    <?php if($this->uri->segment(3) == '') {?>
                                        <div class="row">
                                            <div class="col-sm-12">
                                                <p>
                                                    Please Filter your search to assign roles to desired members
                                                </p>
                                                <hr>
                                                <h6>
                                                    <b>
                                                        Filter To Continue
                                                    </b>
                                                </h6>
                                            </div>
                                        </div>
                                    <?php } else {?>
                                        <div class="row">
                                            <div class="col-sm-12">
                                                <h5>
                                                    Search Results &nbsp;(<b><?php echo count($results)?></b>)
                                                </h5>
                                            </div>
                                        </div>
                                        <hr>
                                        <div class="table-responsive">
                                            <table id="myTable" class="table table-bordered table-striped">
                                                <thead>
                                                <tr>
                                                    <th> Name </th>
                                                    <th> Gender</th>
                                                    <th> County</th>
                                                    <th> Constituency</th>
                                                    <th> Ward</th>
                                                    <th>Role</th>
                                                    <th>Actions</th>
                                                </tr>
                                                </thead>
                                                <tbody>
                                                <?php foreach ($results as $result) {?>
                                                    <?php
                                                    $user_county = $this->User_model->get_county($result->county);
                                                    $user_constituency = $this->User_model->get_constituency($result->constituency);
                                                    $user_ward = $this->User_model->get_ward($result->ward);
                                                    $user_gender = $this->User_model->get_gender($result->sex);
                                                    ?>
                                                    <tr>
                                                        <td>
                                                            <input type="hidden" name="user_id[]" value="<?php echo $result->user_id?>">
                                                            <?php echo ucwords(strtolower($result->fname." ".$result->other_names), " ")?>
                                                        </td>
                                                        <td>
                                                            <?php echo ucfirst(strtolower($user_gender))?>
                                                        </td>
                                                        <td>
                                                            <?php echo ucfirst(strtolower($user_county))?>
                                                        </td>
                                                        <td>
                                                            <?php echo ucfirst(strtolower($user_constituency))?>
                                                        </td>
                                                        <td>
                                                            <?php echo ucfirst(strtolower($user_ward))?>
                                                        </td>
                                                        <td id="user_role<?php echo $result->id?>">
                                                            <?php

                                                            $role_name = $this->Admin_model->get_role_name($result->role);

                                                            ?>
                                                            <?php if($role_name) {?>
                                                                <span class="label label-inverse label-sm">
                                                                    <?php echo $role_name ;?>
                                                                </span>
                                                            <?php } else {?>
                                                                <b>
                                                                    <b>
                                                                        None
                                                                    </b>
                                                                </b>
                                                            <?php }?>
                                                        </td>
                                                        <td>
                                                            <ul class="list-inline">
                                                                <li>
                                                                    <div class="btn-group">
                                                                        <button type="button" class="btn btn-success btn-sm dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                                            Assign Role
                                                                        </button>
                                                                        <div class="dropdown-menu">
                                                                            <?php foreach ($roles as $role) {?>
                                                                                <a class="dropdown-item" href="#" onclick="assign_role('<?php echo $role->id?>', '<?php echo $result->user_id?>', '<?php echo $result->id?>')">
                                                                                    <?php echo $role->name ;?>
                                                                                </a>
                                                                            <?php }?>
                                                                        </div>
                                                                    </div>
                                                                </li>
                                                                <li>
                                                                    <button class="btn btn-inverse btn-sm" onclick="deny_role('<?php echo $result->user_id?>', '<?php echo $result->id?>')">
                                                                        <i class="fa fa-remove"></i>
                                                                    </button>
                                                                </li>
                                                                <li>
                                                                    &nbsp;
                                                                    <i class="fa fa-check-circle" id="check_one<?php echo $result->id?>" style="color: green; font-size: 16px; display: <?php echo ($result->role > 0 ? '' : 'none')?>;"></i>
                                                                </li>
                                                            </ul>
                                                        </td>
                                                    </tr>
                                                <?php }?>
                                                </tbody>
                                                <tfoot>
                                                <tr>
                                                    <th> Name </th>
                                                    <th> Gender</th>
                                                    <th> County</th>
                                                    <th> Constituency</th>
                                                    <th> Ward</th>
                                                    <th>Role</th>
                                                    <th> Actions</th>
                                                </tr>
                                                </tfoot>
                                            </table>
                                        </div>
                                    <?php }?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php /*$this->load->view('user/pages/social_links')*/?>
    </div>
</div>
