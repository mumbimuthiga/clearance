<div class="row page-titles">
    <div class="col-md-5 align-self-center">
        <h5 class="text-themecolor">
            <b>
                <b>
                    Admin > &nbsp;
                </b>
            </b>
            &nbsp;<?php echo ucwords(strtolower(str_replace('_', ' ', $page)), "")?>
        </h5>
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="javascript:void(0)">

                </a></li>
        </ol>
    </div>
    <div class="col-md-7 align-self-center text-right d-none d-md-block">
    </div>
</div>