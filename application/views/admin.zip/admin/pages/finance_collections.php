<style>
    #chartdiv_finance {
        width		: 100%;
        height		: 360px;
        font-size	: 11px;
    }

</style>


<div class="container-fluid">
    <?php $this->load->view('admin/pages/head_info') ;?>
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-body">
                    <h5>
                        ODM Finance Collection in <?php echo date('Y') ;?>
                    </h5>
                    <hr>
                    <div id="chartdiv_finance"></div>
                </div>
            </div>
        </div>
        <?php /*$this->load->view('user/pages/social_links')*/?>
    </div>
</div>

