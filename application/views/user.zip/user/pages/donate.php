<div class="container-fluid">
    <?php $this->load->view('user/pages/head_info') ;?>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-12">
                            <form id="donation_form" action="<?php echo base_url('member/donate_amount')?>"
                                  method="post">
                                <div id="donateForm" class="modal fade" tabindex="-1" role="dialog"
                                     aria-labelledby="myModalLabel" aria-hidden="true"
                                     style="display: none;">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h4 class="modal-title">Donate To ODM</h4>
                                                <button type="button" class="close" data-dismiss="modal"
                                                        aria-hidden="true">×
                                                </button>
                                            </div>
                                            <div class="modal-body">
                                                <div class="form-group">
                                                    <label for="phone">
                                                        Amount
                                                    </label>
                                                    <input type="number" class="form-control" name="amount"
                                                           id="amount" required
                                                           placeholder="Enter Amount">
                                                </div>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button"
                                                        class="btn btn-default waves-effect btn-sm"
                                                        data-dismiss="modal">Close
                                                </button>

                                                <button type="submit"
                                                        class="btn btn-success waves-effect waves-light btn-sm">
                                                    Make Donation
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                        <div class="col-sm-10">
                            <h5>
                                My Donations History
                            </h5>
                        </div>
                        <div class="col-sm-2">
                            <button class="btn btn-inverse" data-toggle="modal" data-target="#donateForm">
                                Donate to ODM
                            </button>
                        </div>
                    </div>
                    <hr>
                    <div class="table-responsive">
                        <table id="myTable" class="table table-bordered table-striped">
                            <thead>
                            <tr>
                                <th> Amount Donated</th>
                                <th> Date Donated</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php foreach ($donations as $donation) {?>

                                <tr>
                                    <td>
                                        <?php echo "Kshs. ".number_format($donation->amount) ;?>
                                    </td>
                                    <td>
                                        <?php echo date_format(date_create($donation->date), 'jS F Y') ;?>
                                    </td>
                                </tr>
                            <?php }?>
                            </tbody>
                            <tfoot>
                            <tr>
                                <th> Amount Donated</th>
                                <th> Date Donated</th>
                            </tr>
                            </tfoot>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
