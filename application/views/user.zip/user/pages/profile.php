<div class="container-fluid">
    <?php $this->load->view('user/pages/head_info') ;?>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card">
                    <div class="card-body p-b-0">
                        <!-- Nav tabs -->
                        <ul class="nav nav-tabs customtab" role="tablist">
                            <li class="nav-item"> <a class="nav-link active" data-toggle="tab" href="#info" role="tab"><span class="hidden-sm-up"><i class="ti-info"></i></span> <span class="hidden-xs-down">Profile</span></a> </li>
                            <li class="nav-item"> <a class="nav-link" data-toggle="tab" href="#update" role="tab"><span class="hidden-sm-up"><i class="ti-pencil"></i></span> <span class="hidden-xs-down">Update Profile</span></a> </li>
                            <li class="nav-item"> <a class="nav-link" data-toggle="tab" href="#password" role="tab"><span class="hidden-sm-up"><i class="ti-lock"></i></span> <span class="hidden-xs-down">Change Password</span></a> </li>
                        </ul>
                        <div class="tab-content">
                            <div class="tab-pane active" id="info" role="tabpanel">
                                <br>
                                <h4>
                                    Profile Information
                                </h4>
                                <hr>
                                <div class="row">
                                    <div class="col-md-4">
                                        <div class="card" style="border: solid 1px lightgrey;">
                                            <div class="card-body">
                                                <div class="table-responsive">
                                                    <table class="table table-bordered table-hover table-striped" style="border: 1px solid #dee2e6 !important;">
                                                        <tr>
                                                            <th>
                                                                First Name
                                                            </th>
                                                            <td>
                                                                <?php echo ucwords(strtolower($details->fname), " ") ;?>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <th>
                                                                Other Names
                                                            </th>
                                                            <td>
                                                                <?php echo ucwords(strtolower($details->other_names), " ") ;?>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <th>
                                                                Gender
                                                            </th>
                                                            <td>
                                                                <?php

                                                                    $gender = $this->User_model->get_gender($details->sex);

                                                                    echo ucfirst($gender);
                                                                ?>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <th>
                                                                Phone Number
                                                            </th>
                                                            <td>
                                                                <?php echo $details->phone ;?>
                                                            </td>
                                                        </tr>

                                                        <tr>
                                                            <th>
                                                                Email Address
                                                            </th>
                                                            <td>
                                                                <?php echo $details->email ;?>
                                                            </td>
                                                        </tr>

                                                        <tr>
                                                            <th>
                                                                Date of Birth
                                                            </th>
                                                            <td>
                                                                <?php echo date_format(date_create($details->dob), 'jS F, Y') ;?>
                                                            </td>
                                                        </tr>

                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="card" style="border: solid 1px lightgrey;">
                                            <div class="card-body">
                                                <div class="table-responsive">
                                                    <table class="table table-bordered table-hover table-striped" style="border: 1px solid #dee2e6 !important;">
                                                        <tr>
                                                            <th>
                                                                Identity Doc
                                                            </th>
                                                            <td>
                                                                <?php

                                                                $doc = $this->User_model->get_identification_doc($details->doc_type);

                                                                echo $doc;
                                                                ?>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <th>
                                                                ID / PassPort No.
                                                            </th>
                                                            <td>
                                                                <?php echo $details->doc_no ;?>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <th>
                                                                Voters No.
                                                            </th>
                                                            <td>
                                                                <?php echo $details->voters_no ;?>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <th>
                                                                Membership No.
                                                            </th>
                                                            <td>
                                                                <?php echo $details->member_no ;?>
                                                            </td>
                                                        </tr>

                                                        <tr>
                                                            <th>
                                                                Interest Group
                                                            </th>
                                                            <td>
                                                                <?php

                                                                $int_groups = explode(",", $details->interest_group);

                                                                $interest_group = $this->User_model->get_interest_group_array($int_groups);

                                                                foreach ($interest_group as $value)
                                                                {
                                                                    echo "$value->name, ";
                                                                }

                                                                ?>
                                                            </td>
                                                        </tr>

                                                        <tr>
                                                            <th>
                                                                Religion
                                                            </th>
                                                            <td>
                                                                <?php echo $details->religion ;?>
                                                            </td>
                                                        </tr>

                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="card" style="border: solid 1px lightgrey;">
                                            <div class="card-body">
                                                <div class="table-responsive">
                                                    <table class="table table-bordered table-hover table-striped" style="border: 1px solid #dee2e6 !important;">
                                                        <tr>
                                                            <th>
                                                                County
                                                            </th>
                                                            <td>
                                                                <?php

                                                                $user_county = $this->User_model->get_county($details->county);

                                                                echo $user_county;
                                                                ?>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <th>
                                                                Constituency
                                                            </th>
                                                            <td>
                                                                <?php

                                                                $user_constituency = $this->User_model->get_constituency($details->constituency);

                                                                echo $user_constituency;
                                                                ?>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <th>
                                                                Ward
                                                            </th>
                                                            <td>
                                                                <?php

                                                                $user_ward = $this->User_model->get_ward($details->ward);

                                                                echo $user_ward;
                                                                ?>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <th>
                                                                Polling Station
                                                            </th>
                                                            <td>
                                                                <?php

                                                                $user_polling_station = $this->User_model->get_polling_station($details->polling_station);

                                                                echo $user_polling_station;
                                                                ?>
                                                            </td>
                                                        </tr>

                                                        <tr>
                                                            <th>
                                                                Member Type
                                                            </th>
                                                            <td>
                                                                <?php

                                                                $member_type = $this->User_model->get_membership($details->member_type);

                                                                echo $member_type->name;
                                                                ?>
                                                            </td>
                                                        </tr>

                                                        <tr>
                                                            <th>
                                                                Date Registered
                                                            </th>
                                                            <td>
                                                                <?php echo date_format(date_create($details->date), 'jS F, Y') ;?>
                                                            </td>
                                                        </tr>

                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="tab-pane " id="update" role="tabpanel">
                                <br>
                                <h4>
                                    Update Profile Information
                                </h4>
                                <hr>
                                <form class="form-horizontal" method="post" id="profile_form" action="<?php echo base_url('member/update_profile')?>">
                                    <div class="row">
                                        <div class="col-sm-4" style="border-right: solid 1px lightgrey">
                                            <div class="form-group">
                                                <label for="fname_reg">
                                                    First Name
                                                </label>
                                                <input type="text" class="form-control" id="fname_reg" name="fname" value="<?php echo $details->fname?>" required oninput="check_fname()">
                                                <span class="help-block" id="fname_error" style="display: none; color: red">
                                                First name must be letters only
                                            </span>
                                            </div>
                                            <div class="form-group">
                                                <label for="other_names_reg">
                                                    Other Names
                                                </label>
                                                <input type="text" class="form-control" id="other_names_reg" name="other_names" value="<?php echo $details->other_names?>" required oninput="check_other_names()">
                                                <span class="help-block" id="other_names_error" style="display: none; color: red">
                                                Other names must be letters only
                                            </span>
                                            </div>
                                            <div class="form-group">
                                                <label for="email_reg">
                                                    Email Address
                                                </label>
                                                <input type="email" class="form-control" id="email_reg" name="email" value="<?php echo $details->email?>" required oninput="check_email()">
                                                <span class="help-block" id="email_error" style="display: none; color: red">
                                                Enter correct email address
                                            </span>
                                            </div>
                                            <div class="form-group">
                                                <label for="phone_reg">
                                                    Phone Number
                                                </label>
                                                <input type="number" class="form-control" id="phone_reg" name="phone" value="<?php echo $details->phone?>" required placeholder="e.g 07xxxxxxxx" oninput="check_phone()">
                                                <span class="help-block" id="phone_error" style="display: none; color: red">
                                                Phone number must be 10 characters long
                                            </span>
                                            </div>
                                            <div class="form-group">
                                                <label for="religion">
                                                    Religion
                                                </label>
                                                <select id="religion" class="form-control select2" style="width: 100%" name="religion" required>
                                                    <option value="">--- Add Religion ---</option>
                                                    <option value="Christian" <?php echo ($details->religion == 'Christian' ? 'selected' : '') ;?>>Christian</option>
                                                    <option value="Islam" <?php echo ($details->religion == 'Islam' ? 'selected' : '') ;?>>Islam</option>
                                                    <option value="Hindu" <?php echo ($details->religion == 'Hindu' ? 'selected' : '') ;?>>Hindu</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-sm-4" style="border-right: solid 1px lightgrey">
                                            <div class="form-group">
                                                <label for="doc_type">
                                                    Identification Document
                                                </label>
                                                <select class="form-control select2" style="width: 100%" name="doc_type" required id="doc_type">
                                                    <option value="">--- Add Document ---</option>
                                                    <?php foreach ($documents as $document) {?>
                                                        <option value="<?php echo $document->id?>" <?php echo ($document->id == $details->doc_type ? 'selected' : '') ;?>>
                                                            <?php echo ucwords(strtolower($document->doc_name), " ")?>
                                                        </option>
                                                    <?php }?>
                                                </select>
                                            </div>
                                            <div class="form-group">
                                                <label for="idno">
                                                    ID / Passport Number
                                                </label>
                                                <input type="number" class="form-control" id="idno" value="<?php echo $details->doc_no ;?>" name="doc_id" required>
                                            </div>
                                            <div class="form-group">
                                                <label for="iebc_v_no">
                                                    IEBC Voters Number
                                                </label>
                                                <input type="number" class="form-control" id="iebc_v_no" name="voters_no" value="<?php echo $details->voters_no ;?>" required>
                                            </div>
                                            <div class="form-group">
                                                <label for="member_no">
                                                    ODM Membership Number
                                                </label>
                                                <input type="text" class="form-control" id="member_no" name="member_no" value="<?php echo $details->member_no?>" required>
                                            </div>
                                            <div class="form-group">
                                                <label for="interest_groups">
                                                    Interest Groups
                                                </label>
                                                <select class="select2 m-b-10 select2-multiple" style="width: 100%" multiple="multiple" name="interest_groups[]" required id="interest_groups">
                                                    <option value="">--- Add Group ---</option>
                                                    <?php foreach ($groups as $group) {?>
                                                        <?php

                                                            $i_groups = explode(",", $details->interest_group);

                                                        ?>
                                                        <option value="<?php echo $group->id?>" <?php echo (in_array($group->id, $i_groups) ? 'selected' : '') ;?>>
                                                            <?php echo ucwords(strtolower($group->name), " ")?>
                                                        </option>
                                                    <?php }?>
                                                </select>
                                            </div>

                                        </div>
                                        <div class="col-sm-4">
                                            <div class="form-group">
                                                <label for="county">
                                                    County
                                                </label>
                                                <select class="form-control select2" name="county" style="width: 100%" required id="county" onchange="get_constituencies()">
                                                    <option value="">--- Add County ---</option>
                                                    <?php foreach ($counties as $county) {?>
                                                        <option value="<?php echo $county->id?>" <?php echo ($county->id == $details->county ? 'selected' : '') ;?>>
                                                            <?php echo ucwords(strtolower($county->name), " ")?>
                                                        </option>
                                                    <?php }?>
                                                </select>
                                            </div>
                                            <div class="form-group">
                                                <label for="constituency">
                                                    Constituencies
                                                </label>
                                                <select class="form-control select2" name="constituency" style="width: 100%" required id="constituency" onchange="get_wards()">
                                                    <option value="">--- Add Constituency ---</option>
                                                    <?php foreach ($constituencies as $constituency) {?>
                                                        <option value="<?php echo $constituency->id?>" <?php echo ($constituency->id == $details->constituency ? 'selected' : '') ;?>>
                                                            <?php echo ucwords(strtolower($constituency->name), " ")?>
                                                        </option>
                                                    <?php }?>
                                                </select>
                                            </div>
                                            <div class="form-group">
                                                <label for="wards">
                                                    Ward
                                                </label>
                                                <select class="form-control select2" name="ward" style="width: 100%" required id="wards" onchange="get_polling_stations()">
                                                    <option value="">--- Add Ward ---</option>
                                                    <?php foreach ($wards as $ward) {?>
                                                        <option value="<?php echo $ward->id?>" <?php echo ($ward->id == $details->ward ? 'selected' : '') ;?>>
                                                            <?php echo ucwords(strtolower($ward->name), " ")?>
                                                        </option>
                                                    <?php }?>
                                                </select>
                                            </div>
                                            <div class="form-group">
                                                <label for="polling">
                                                    Polling Station
                                                </label>
                                                <select class="form-control select2" style="width: 100%" name="p_station" required id="polling">
                                                    <option value="">--- Add Polling Station ---</option>
                                                    <?php foreach ($polling_stations as $station) {?>
                                                        <option value="<?php echo $station->id?>" <?php echo ($station->id == $details->polling_station ? 'selected' : '') ;?>>
                                                            <?php echo ucwords(strtolower($station->name), " ")?>
                                                        </option>
                                                    <?php }?>
                                                </select>
                                            </div>
                                            <div class="form-group text-center m-t-20">
                                                <div class="col-xs-12">
                                                    <hr>
                                                    <button class="btn btn-warning btn-md" type="submit" style="width: 100%;">
                                                        Update Profile
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>

                            <div class="tab-pane " id="password" role="tabpanel">
                                <br>
                                <form class="form-horizontal" method="post" id="password_form" action="<?php echo base_url('member/update_password')?>">
                                    <div class="row">
                                        <div class="col-sm-6">
                                            <h4>
                                                Update Your Password
                                            </h4>
                                            <hr>
                                            <div class="form-group">
                                                <label for="pass_old">
                                                    Existing Password
                                                </label>
                                                <input type="password" class="form-control" id="pass_old" name="pass_old" required>
                                            </div>
                                            <div class="form-group">
                                                <label for="pass1_reg">
                                                    New Password
                                                </label>
                                                <input type="password" class="form-control" id="pass1_reg" name="pass1" required oninput="check_pass1()">
                                                <span class="help-block" id="pass1_error" style="display: none; color: red">
                                                Password must be at least 8 characters long
                                            </span>
                                            </div>
                                            <div class="form-group">
                                                <label for="pass2_reg">
                                                    Confirm Password
                                                </label>
                                                <input type="password" class="form-control" id="pass2_reg" name="pass2" required oninput="check_pass2()">
                                                <span class="help-block" id="pass_mismatch" style="display: none; color: red">
                                                Passwords do not match
                                            </span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-12">
                                            <hr>
                                            <div class="form-group m-t-20">
                                                <div class="col-xs-12">
                                                    <button class="btn btn-warning btn-md" type="submit">
                                                    <span class="text-center" id="login_text_default">
                                                            Update Password
                                                    </span>
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <?php $this->load->view('user/pages/social_links')?>
    </div>
</div>
