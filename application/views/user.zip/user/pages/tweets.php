<div class="container-fluid">
    <?php $this->load->view('user/pages/head_info') ;?>

    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6" style="margin-bottom: 15px;">
                            <div class="card" id="support_issues_border">
                               <div class="card-body">
                                   <h5>
                                       ODM Recent Tweets
                                   </h5>
                                   <hr>
                                   <div style="max-height: 60vh; overflow: auto;">
                                       <a class="twitter-timeline" data-link-color="#2B7BB9" href="https://twitter.com/TheODMparty?ref_src=twsrc%5Etfw">Tweets by TheODMparty</a> <script async src="https://platform.twitter.com/widgets.js" charset="utf-8"></script>
                                   </div>
                               </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                           <div class="card" id="support_issues_border">
                               <div class="card-body">
                                   <h5>
                                       Get In Touch
                                   </h5>
                                   <hr>
                                   <br>
                                   <h6>
                                       Tweet ODM Party
                                   </h6>
                                   <a href="https://twitter.com/intent/tweet?screen_name=TheODMparty&ref_src=twsrc%5Etfw" class="twitter-mention-button" data-size="large" data-show-count="false">Tweet to @TheODMparty</a><script async src="https://platform.twitter.com/widgets.js" charset="utf-8"></script>
                                   <hr>

                                   <h6>
                                       Follow ODM Party
                                   </h6>
                                   <a href="https://twitter.com/TheODMparty?ref_src=twsrc%5Etfw" class="twitter-follow-button" data-size="large" data-show-count="false">Follow @TheODMparty</a><script async src="https://platform.twitter.com/widgets.js" charset="utf-8"></script>
                                   <hr>

                               </div>
                           </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="<?php echo base_url() ?>assets/node_modules/jquery/jquery.min.js"></script>

<script type="text/javascript">
    (function check_membership_status() {
        $.ajax({
            type: "POST",
            url: "<?php echo base_url('member/check_member_expiry_date/'.$s_id)?>",
            success: function () {
            },
            complete: function () {
                setTimeout(check_membership_status, 3600);
            }
        });
    })();
</script>

