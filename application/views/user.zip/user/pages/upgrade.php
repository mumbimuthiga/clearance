<div class="container-fluid">
    <?php $this->load->view('user/pages/head_info') ;?>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-sm-9">
                            <h4>
                                Available Memberships
                            </h4>
                        </div>
                        <div class="col-sm-3">
                            <button class="btn btn-inverse" id="renew_membership">
                                Renew Current Membership
                            </button>
                        </div>
                    </div>
                    <hr>
                    <div class="row">
                        <?php foreach ($memberships as $membership) {?>
                            <div class="col-sm-4">
                                <div class="card" id="support_issues_border">
                                    <div class="card-body">
                                        <div class="row">
                                            <div class="col-7">
                                                <h6>
                                                    <?php echo $membership->name?>
                                                </h6>
                                            </div>
                                            <div class="col-5">
                                                <h6 class="text-sm-right">
                                                    <b>
                                                        Ksh. <?php echo number_format($membership->fee)?>
                                                    </b>
                                                </h6>
                                            </div>
                                        </div>
                                        <hr>
                                        <div class="row">
                                            <div class="col-12">
                                                <h5>
                                                    Advantage
                                                </h5>
                                                <hr>
                                                <div style="height: 100px; overflow: auto;">
                                                    <p>
                                                        <?php echo $membership->advantage ;?>
                                                    </p>
                                                </div>
                                                <hr>
                                                <?php if($details->member_type == $membership->id) {?>
                                                    <span class="label label-inverse" style="margin-bottom: 8px;">
                                                        Current Membership
                                                    </span>
                                                <?php } else {?>
                                                    <button class="btn btn-sm btn-success" onclick="upgrade_membership('<?php echo $membership->id?>')">
                                                        Upgrade
                                                    </button>
                                                <?php }?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php }?>
                    </div>
                </div>
            </div>
        </div>
        <?php $this->load->view('user/pages/social_links') ;?>
    </div>
</div>

