<div class="container-fluid">
    <?php $this->load->view('user/pages/head_info') ;?>
    <div class="row">
        <div class="col-sm-6 offset-sm-3" id="members_card_body">
            <div id="member_card">
                <div class="card" style="border: solid 1px">
                    <div class="card-body">
                        <div class="col-12">
                            <div>
                                <div class="row">
                                    <div class="col-sm-8">
                                        <h6>
                                            <b>
                                                Membership No :&nbsp;
                                            </b>
                                            <?php echo ($details->member_no ? $details->member_no : 'Not Assigned')?>
                                        </h6>
                                        <br>
                                        <h6>
                                            <b>
                                                Date Printed :&nbsp;
                                            </b>
                                            <?php echo date_format(date_create(date('Y-m-d')), 'jS F, Y') ;?>
                                        </h6>
                                    </div>
                                    <div class="col-sm-4">
                                        <img src="<?php echo base_url(); ?>assets/images/logo2.png" alt="" class="pull-right" />
                                    </div>
                                </div>
                                <hr>
                                <div class="row">
                                    <div class="col-sm-3">
                                        <h6>
                                            <b>
                                                Name :
                                            </b>
                                        </h6>
                                    </div>
                                    <div class="col-sm-9">
                                        <h6>
                                            <?php
                                                echo ($details->fname && $details->other_names ? ucwords(strtolower($details->fname." ".$details->other_names), " ") : ucwords(strtolower($details->fname), " "))
                                            ?>
                                        </h6>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-sm-3">
                                        <h6>
                                            <b>
                                                Phone No :&nbsp;
                                            </b>
                                        </h6>
                                    </div>
                                    <div class="col-sm-9">
                                        <h6>
                                            <?php echo ($details->phone ? strtolower($details->phone) : 'Not Provided') ;?>
                                        </h6>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-sm-3">
                                        <h6>
                                            <b>
                                                Email :&nbsp;
                                            </b>
                                        </h6>
                                    </div>
                                    <div class="col-sm-9">
                                        <h6>
                                            <?php echo ($details->email ? strtolower($details->email) : 'Not Provided') ;?>
                                        </h6>
                                    </div>
                                </div>
                                <hr>
                                <div class="row">
                                    <div class="col-12">
                                        <div class="text-center">
                                            <h6 style="color:#ff9a58; ">
                                                <b>
                                                    ODM Part Members Card
                                                </b>
                                            </h6>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <br>

            <?php if(!$details->member_no || !$details->phone || !$details->email || !$details->other_names) {?>
                <h6 class="text-warning">
                    Please Complete your profile first. &nbsp;
                </h6>
                <a class="btn btn-outline-inverse" href="<?php echo base_url('member/profile')?>">
                    Complete Profile
                </a>
            <?php } else {?>
                <button class="btn btn-success btn-sm" id="print_card">
                    Print Card
                </button>
                <button class="btn btn-inverse btn-sm" onclick="download_card('<?php echo $details->fname.".pdf"?>')">
                    Download Pdf
                </button>
            <?php }?>
            <br><br>
        </div>

        <?php $this->load->view('user/pages/social_links')?>

    </div>
</div>
