<div class="col-sm-12">
    <hr>
    <div class="card">
        <div class="card-body">
            <h5>
                ODM Social Media Links
            </h5>
            <hr>
            <ul class="list-inline">
                <li style="margin-right: 20px;">
                    <a href="https://www.facebook.com/OfficialODMPartyPage/" target="_blank">
                        <div style="height: 35px; width: 35px;">
                            <img src="<?php echo base_url('assets/images/icons/facebook.png')?>" class="img-responsive" style="width: 100%; height: 100%;" />
                        </div>
                    </a>
                </li>
                <li style="margin-right: 20px;">
                    <a href="https://twitter.com/TheODMparty" target="_blank">
                        <div style="height: 35px; width: 35px;">
                            <img src="<?php echo base_url('assets/images/icons/twitter.png')?>" class="img-responsive" style="width: 100%; height: 100%;" />
                        </div>
                    </a>
                </li>
                <li>
                    <a href="#" target="_blank">
                        <div style="height: 35px; width: 35px;">
                            <img src="<?php echo base_url('assets/images/icons/linkedin.png')?>" class="img-responsive" style="width: 100%; height: 100%;" />
                        </div>
                    </a>
                </li>
            </ul>
        </div>
    </div>
</div>