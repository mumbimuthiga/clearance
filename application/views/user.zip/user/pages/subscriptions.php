<div class="container-fluid">
    <?php $this->load->view('user/pages/head_info') ;?>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body p-b-0">
                    <!-- Nav tabs -->
                    <ul class="nav nav-tabs customtab" role="tablist">
                        <li class="nav-item"> <a class="nav-link <?php echo ($this->uri->segment(3) == '' ? 'active' : '')?>" data-toggle="tab" href="#messages" role="tab"><span class="hidden-sm-up"><i class="ti-pencil"></i></span> <span class="hidden-xs-down">Email / SMS Subscription</span></a> </li>
                        <li class="nav-item"> <a class="nav-link <?php echo ($this->uri->segment(3) != '' ? 'active' : '')?>" data-toggle="tab" href="#ivr" role="tab"><span class="hidden-sm-up"><i class="ti-info"></i></span> <span class="hidden-xs-down">IVR Subcriptions</span></a> </li>
                    </ul>
                    <div class="tab-content">
                        <div class="tab-pane  <?php echo ($this->uri->segment(3) == '' ? 'active' : '')?>" id="messages" role="tabpanel">
                            <br>
                            <h4>
                                Subscription Information
                            </h4>
                            <hr>
                            <p>
                                By subscribing to this module, you accept to receive emails and /or sms from ODM at <b><b>Ksh. 10</b></b>, for every sms.
                            </p>
                            <br>
                            <h6>
                                Dial
                                <b>
                                    <b>
                                        *458*8#
                                    </b>
                                </b>
                                 to subscribe to SMS alerts.
                            </h6>
                        </div>
                        <div class="tab-pane <?php echo ($this->uri->segment(3) != '' ? 'active' : '')?>" id="ivr" role="tabpanel">
                            <br>
                            <h4>
                                Subscribe To IVR from Party Officials
                            </h4>
                            <hr>
                            <div class="row">
                                <div class="col-sm-3" id="support_issues_border">
                                    <br>
                                    <h5>
                                        Choose Category
                                    </h5>
                                    <hr>
                                    <div id="support_issues_container">
                                        <div id="support_issues_item" class="<?php echo ($this->uri->segment(3) == 'leaders' ? 'support_issue_active' : '') ;?>">
                                            <a href="<?php echo base_url('member/subscriptions/leaders')?>">
                                                <div id="support_issues_content">
                                                    <div class="row">
                                                        <div class="col-10">
                                                            <h5>
                                                                <b>
                                                                    Party Leaders
                                                                </b>
                                                            </h5>
                                                        </div>
                                                        <div class="col-2">
                                            <span class="badge badge-success">
                                                <?php echo count($leaders)?>
                                            </span>
                                                        </div>
                                                    </div>
                                                </div>
                                            </a>
                                        </div>

                                        <div id="support_issues_item" class="<?php echo ($this->uri->segment(3) == 'governors' ? 'support_issue_active' : '') ;?>">
                                            <a href="<?php echo base_url('member/subscriptions/governors')?>">
                                                <div id="support_issues_content">
                                                    <div class="row">
                                                        <div class="col-10">
                                                            <h5>
                                                                <b>
                                                                    Governors
                                                                </b>
                                                            </h5>
                                                        </div>
                                                        <div class="col-2">
                                            <span class="badge badge-success">
                                                <?php echo count($governors)?>
                                            </span>
                                                        </div>
                                                    </div>
                                                </div>
                                            </a>
                                        </div>

                                        <div id="support_issues_item" class="<?php echo ($this->uri->segment(3) == 'senators' ? 'support_issue_active' : '') ;?>">
                                            <a href="<?php echo base_url('member/subscriptions/senators')?>">
                                                <div id="support_issues_content">
                                                    <div class="row">
                                                        <div class="col-10">
                                                            <h5>
                                                                <b>
                                                                    Senators
                                                                </b>
                                                            </h5>
                                                        </div>
                                                        <div class="col-2">
                                                    <span class="badge badge-success">
                                                        <?php echo count($senators)?>
                                                    </span>
                                                        </div>
                                                    </div>
                                                </div>
                                            </a>
                                        </div>

                                        <div id="support_issues_item" class="<?php echo ($this->uri->segment(3) == 'mps' ? 'support_issue_active' : '') ;?>">
                                            <a href="<?php echo base_url('member/subscriptions/mps')?>">
                                                <div id="support_issues_content">
                                                    <div class="row">
                                                        <div class="col-10">
                                                            <h5>
                                                                <b>
                                                                    MPs
                                                                </b>
                                                            </h5>
                                                        </div>
                                                        <div class="col-2">
                                            <span class="badge badge-success">
                                                <?php echo count($mps)?>
                                            </span>
                                                        </div>
                                                    </div>
                                                </div>
                                            </a>
                                        </div>

                                        <div id="support_issues_item" class="<?php echo ($this->uri->segment(3) == 'women_rep' ? 'support_issue_active' : '') ;?>">
                                            <a href="<?php echo base_url('member/subscriptions/women_rep')?>">
                                                <div id="support_issues_content">
                                                    <div class="row">
                                                        <div class="col-10">
                                                            <h5>
                                                                <b>
                                                                    Women Rep.
                                                                </b>
                                                            </h5>
                                                        </div>
                                                        <div class="col-2">
                                            <span class="badge badge-success">
                                                <?php echo count($women_rep)?>
                                            </span>
                                                        </div>
                                                    </div>
                                                </div>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-9" id="support_issues_border">
                                    <div class="card">
                                        <div class="card-body">
                                            <?php if($this->uri->segment(3) == '') {?>
                                                <div class="row">
                                                    <div class="col-sm-12">
                                                        <div>
                                                            <p>
                                                                IVR are call back tunes from ODM leaders and and officials. These range from quotes from different officials, messages
                                                                and even motivational talks.
                                                                <br>
                                                                You can subscribe by selecting a category of leaders then check on the short codes provided. Dial on yor phone to subscribe.
                                                            </p>
                                                        </div>
                                                        <hr>
                                                        <h6>
                                                            <b>
                                                                Select a category to get started
                                                            </b>
                                                        </h6>
                                                    </div>
                                                </div>
                                            <?php } else {?>
                                                <?php if($this->uri->segment(3) == 'leaders') {?>
                                                    <h5>
                                                        ODM Officials
                                                    </h5>
                                                    <hr>
                                                    <div class="table-responsive">
                                                        <table id="myTable" class="table table-bordered table-striped">
                                                            <thead>
                                                            <tr>
                                                                <th> Name</th>
                                                                <th> Role</th>
                                                                <th> Short Code</th>
                                                                <th>Guide</th>
                                                            </tr>
                                                            </thead>
                                                            <tbody>
                                                            <?php foreach ($leaders as $leader) {?>
                                                                <?php

                                                                $short_code = $this->User_model->get_user_shortcode($leader->user_id);
                                                                ?>
                                                                <tr>
                                                                    <td>
                                                                        <?php echo ucwords(strtolower($leader->fname." ".$leader->other_names), " ") ;?>
                                                                    </td>
                                                                    <td>
                                                                        <?php echo $leader->role ;?>
                                                                    </td>
                                                                    <td>
                                                                        <p class="text-warning">
                                                                            <b>
                                                                                <b>
                                                                                    <?php echo $short_code ;?>
                                                                                </b>
                                                                            </b>
                                                                        </p>
                                                                    </td>
                                                                    <td>
                                                                        <p class="text-warning">
                                                                            <b>
                                                                                Dial to Subscribe
                                                                            </b>
                                                                        </p>
                                                                    </td>
                                                                </tr>
                                                            <?php }?>
                                                            </tbody>
                                                            <tfoot>
                                                            <tr>
                                                                <th> Name</th>
                                                                <th> Role</th>
                                                                <th> Short Code</th>
                                                                <th>Guide</th>
                                                            </tr>
                                                            </tfoot>
                                                        </table>
                                                    </div>
                                                <?php }?>

                                                <?php if($this->uri->segment(3) == 'governors') {?>
                                                    <h5>
                                                        ODM Governors
                                                    </h5>
                                                    <hr>
                                                    <div class="table-responsive">
                                                        <table id="myTable" class="table table-bordered table-striped">
                                                            <thead>
                                                            <tr>
                                                                <th> Name</th>
                                                                <th> County</th>
                                                                <th> Short Code</th>
                                                                <th>Guide</th>
                                                            </tr>
                                                            </thead>
                                                            <tbody>
                                                            <?php foreach ($governors as $governor) {?>
                                                                <?php

                                                                $short_code_gov = $this->User_model->get_user_shortcode($governor->user_id);
                                                                ?>
                                                                <tr>
                                                                    <td>
                                                                        <?php echo ucwords(strtolower($governor->fname." ".$governor->other_names), " ") ;?>
                                                                    </td>
                                                                    <td>
                                                                        <?php echo $governor->county_id ;?>
                                                                    </td>
                                                                    <td>
                                                                        <p class="text-warning">
                                                                            <b>
                                                                                <b>
                                                                                    <?php echo $short_code_gov ;?>
                                                                                </b>
                                                                            </b>
                                                                        </p>
                                                                    </td>
                                                                    <td>
                                                                        <p class="text-warning">
                                                                            <b>
                                                                                Dial to Subscribe
                                                                            </b>
                                                                        </p>
                                                                    </td>
                                                                </tr>
                                                            <?php }?>
                                                            </tbody>
                                                            <tfoot>
                                                            <tr>
                                                                <th> Name</th>
                                                                <th> County</th>
                                                                <th> Short Code</th>
                                                                <th>Guide</th>
                                                            </tr>
                                                            </tfoot>
                                                        </table>
                                                    </div>
                                                <?php }?>

                                                <?php if($this->uri->segment(3) == 'senators') {?>
                                                    <h5>
                                                        ODM Senators
                                                    </h5>
                                                    <hr>
                                                    <div class="table-responsive">
                                                        <table id="myTable" class="table table-bordered table-striped">
                                                            <thead>
                                                            <tr>
                                                                <th> Name</th>
                                                                <th> County</th>
                                                                <th> Short Code</th>
                                                                <th>Guide</th>
                                                            </tr>
                                                            </thead>
                                                            <tbody>
                                                            <?php foreach ($senators as $senator) {?>
                                                                <?php

                                                                $short_code_sen = $this->User_model->get_user_shortcode($senator->user_id);
                                                                ?>
                                                                <tr>
                                                                    <td>
                                                                        <?php echo ucwords(strtolower($senator->fname." ".$senator->other_names), " ") ;?>
                                                                    </td>
                                                                    <td>
                                                                        <?php echo $senator->county_id ;?>
                                                                    </td>
                                                                    <td>
                                                                        <p class="text-warning">
                                                                            <b>
                                                                                <b>
                                                                                    <?php echo $short_code_sen ;?>
                                                                                </b>
                                                                            </b>
                                                                        </p>
                                                                    </td>
                                                                    <td>
                                                                        <p class="text-warning">
                                                                            <b>
                                                                                Dial to Subscribe
                                                                            </b>
                                                                        </p>
                                                                    </td>
                                                                </tr>
                                                            <?php }?>
                                                            </tbody>
                                                            <tfoot>
                                                            <tr>
                                                                <th> Name</th>
                                                                <th> County</th>
                                                                <th> Short Code</th>
                                                                <th>Guide</th>
                                                            </tr>
                                                            </tfoot>
                                                        </table>
                                                    </div>
                                                <?php }?>

                                                <?php if($this->uri->segment(3) == 'mps') {?>
                                                    <h5>
                                                        ODM MPs
                                                    </h5>
                                                    <hr>
                                                    <div class="table-responsive">
                                                        <table id="myTable" class="table table-bordered table-striped">
                                                            <thead>
                                                            <tr>
                                                                <th> Name</th>
                                                                <th> Constituency</th>
                                                                <th> Short Code</th>
                                                                <th>Guide</th>
                                                            </tr>
                                                            </thead>
                                                            <tbody>
                                                            <?php foreach ($mps as $mp) {?>
                                                                <?php

                                                                $short_code_mp = $this->User_model->get_user_shortcode($mp->user_id);
                                                                ?>
                                                                <tr>
                                                                    <td>
                                                                        <?php echo ucwords(strtolower($mp->fname." ".$mp->other_names), " ") ;?>
                                                                    </td>
                                                                    <td>
                                                                        <?php echo $mp->constituency_id ;?>
                                                                    </td>
                                                                    <td>
                                                                        <p class="text-warning">
                                                                            <b>
                                                                                <b>
                                                                                    <?php echo $short_code_mp ;?>
                                                                                </b>
                                                                            </b>
                                                                        </p>
                                                                    </td>
                                                                    <td>
                                                                        <p class="text-warning">
                                                                            <b>
                                                                                Dial to Subscribe
                                                                            </b>
                                                                        </p>
                                                                    </td>
                                                                </tr>
                                                            <?php }?>
                                                            </tbody>
                                                            <tfoot>
                                                            <tr>
                                                                <th> Name</th>
                                                                <th> Constituency</th>
                                                                <th> Short Code</th>
                                                                <th>Guide</th>
                                                            </tr>
                                                            </tfoot>
                                                        </table>
                                                    </div>
                                                <?php }?>

                                                <?php if($this->uri->segment(3) == 'women_rep') {?>
                                                    <h5>
                                                        ODM Women Representatives
                                                    </h5>
                                                    <hr>
                                                    <div class="table-responsive">
                                                        <table id="myTable" class="table table-bordered table-striped">
                                                            <thead>
                                                            <tr>
                                                                <th> Name</th>
                                                                <th> County</th>
                                                                <th> Short Code</th>
                                                                <th>Guide</th>
                                                            </tr>
                                                            </thead>
                                                            <tbody>
                                                            <?php foreach ($women_rep as $value) {?>
                                                                <?php

                                                                $short_code_wr = $this->User_model->get_user_shortcode($value->user_id);
                                                                ?>
                                                                <tr>
                                                                    <td>
                                                                        <?php echo ucwords(strtolower($value->fname." ".$value->other_names), " ") ;?>
                                                                    </td>
                                                                    <td>
                                                                        <?php echo $value->county_id ;?>
                                                                    </td>
                                                                    <td>
                                                                        <p class="text-warning">
                                                                            <b>
                                                                                <b>
                                                                                    <?php echo $short_code_wr ;?>
                                                                                </b>
                                                                            </b>
                                                                        </p>
                                                                    </td>
                                                                    <td>
                                                                        <p class="text-warning">
                                                                            <b>
                                                                                Dial to Subscribe
                                                                            </b>
                                                                        </p>
                                                                    </td>
                                                                </tr>
                                                            <?php }?>
                                                            </tbody>
                                                            <tfoot>
                                                            <tr>
                                                                <th> Name</th>
                                                                <th> County</th>
                                                                <th> Short Code</th>
                                                                <th>Guide</th>
                                                            </tr>
                                                            </tfoot>
                                                        </table>
                                                    </div>
                                                <?php }?>

                                            <?php }?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <br>
                </div>
            </div>
        </div>
        <?php $this->load->view('user/pages/social_links')?>
    </div>
</div>
